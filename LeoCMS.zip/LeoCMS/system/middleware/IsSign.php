<?php namespace system\middleware;

use houdunwang\middleware\build\Middleware;
use houdunwang\session\Session;

class IsSign implements Middleware{
	//执行中间件
	public function run($next) {
         if(!Session::has('cmsAdmin')) return redirect('admin.Admin.login');
         $next();
	}
}