<?php namespace system\middleware;

use houdunwang\middleware\build\Middleware;
use system\model\Wechat_config;

class Wechat implements Middleware{
	//执行中间件
	public function run($next) {
	    $data = json_decode(Wechat_config::find(1)['config'], true);
	    if(!empty($data)) {
            Config::set('wechat', array_merge(Config::get('wechat'), $data));
            foreach($data as $k=>$v) {
                v($k, $v);
            }
        }
        $next();
	}
}