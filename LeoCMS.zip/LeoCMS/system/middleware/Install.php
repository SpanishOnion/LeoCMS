<?php namespace system\middleware;

use houdunwang\middleware\build\Middleware;

class Install implements Middleware{
	//执行中间件
	public function run($next) {
         if(!is_file('./lock.php')) return redirect('system.Install.copyright');
         $next();
	}
}