<?php namespace system\model;
use hdphp\session\Session;
use houdunwang\code\Code;
use houdunwang\model\Model;
class Admin extends Model{
	//数据表
	protected $table = "admin";

	//允许填充字段
	protected $allowFill = ['*'];

	//禁止填充字段
	protected $denyFill = [ ];

	//自动验证
	protected $validate=[
		//['字段名','验证方法','提示信息',验证条件,验证时间]
	];

	//自动完成
	protected $auto=[
		//['字段名','处理方法','方法类型',验证条件,验证时机]
	];

	//自动过滤
    protected $filter=[
        //[表单字段名,过滤条件,处理时间]
    ];

	//时间操作,需要表中存在created_at,updated_at字段
	protected $timestamps=true;

	public static function check()
    {
        if(!Code::auth('code')) {
            echo 0;
        } else {
            $info = self::where('username','=',$_POST['username'])->first();
            if(empty($info)) {
                echo 1;
            } else {
                $info = $info->toArray();
                if($info['password'] == $_POST['password']) {
                    Session::set('cmsAdmin', $info['nickname']);
                    echo 3;
                    self::find($info['id'])->save(['ltime' => time()]);
                } else {
                    echo 2;
                }
            }
        }
    }
}