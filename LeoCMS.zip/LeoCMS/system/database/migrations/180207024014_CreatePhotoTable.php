<?php namespace system\database\migrations;
use houdunwang\database\build\Migration;
use houdunwang\database\build\Blueprint;
use houdunwang\database\Schema;
class CreatePhotoTable extends Migration {
    //执行
	public function up() {
		Schema::create( 'photo', function ( Blueprint $table ) {
			$table->increments( 'id' );
            $table->char('title', 50)->defaults('')->comment('轮播图标题');
            $table->char('thumb', 150)->defaults('')->comment('轮播图路径');
            $table->char('link', 150)->defaults('')->comment('轮播图链接');
            $table->integer('adtime')->unsigned()->defaults(0)->comment('添加时间');
        });
    }

    //回滚
    public function down() {
        Schema::drop( 'photo' );
    }
}