<?php namespace system\database\migrations;
use houdunwang\database\build\Migration;
use houdunwang\database\build\Blueprint;
use houdunwang\database\Schema;
class CreateAdminTable extends Migration {
    //执行
	public function up() {
		Schema::create( 'admin', function ( Blueprint $table ) {
			$table->increments( 'id' );
            $table->char('username', 20)->defaults('')->comment('用户名');
            $table->char('password', 30)->defaults('')->comment('密码');
            $table->integer('rtime')->unsigned()->comment('注册时间');
            $table->integer('ltime')->unsigned()->comment('登陆时间');
        });
    }

    //回滚
    public function down() {
        Schema::drop( 'admin' );
    }
}