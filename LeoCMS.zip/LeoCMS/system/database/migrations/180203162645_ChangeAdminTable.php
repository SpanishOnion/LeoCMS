<?php namespace system\database\migrations;
use houdunwang\database\build\Migration;
use houdunwang\database\build\Blueprint;
use houdunwang\database\Schema;
class ChangeAdminTable extends Migration {
    //执行
	public function up() {
		Schema::table( 'admin', function ( Blueprint $table ) {
			//$table->string('name', 50)->add();
            $table->char('nickname',20)->defaults('')->comment('昵称')->add();
        });
    }

    //回滚
    public function down() {
            //Schema::dropField('admin', 'name');
    }
}