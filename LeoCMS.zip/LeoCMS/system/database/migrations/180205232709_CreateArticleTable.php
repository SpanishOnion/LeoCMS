<?php namespace system\database\migrations;
use houdunwang\database\build\Migration;
use houdunwang\database\build\Blueprint;
use houdunwang\database\Schema;
class CreateArticleTable extends Migration {
    //执行
	public function up() {
		Schema::create( 'article', function ( Blueprint $table ) {
			$table->increments( 'id' );
			$table->smallint('cid')->index()->comment('分类id');
            $table->char('title', 30)->defaults('')->comment('文章标题');
            $table->char('digest', 50)->defaults('')->comment('文章摘要');
            $table->char('author', 20)->defaults('')->comment('文章作者');
            $table->text('content')->comment('文章内容');
            $table->smallint('click')->defaults(0)->comment('点击数量');
            $table->tinyInteger('recycle')->defaults(0)->comment('是否在回收站');
            $table->integer('adtime')->unsigned()->defaults(0)->comment('添加时间');
            $table->integer('uptime')->unsigned()->defaults(0)->comment('修改时间');
        });
    }

    //回滚
    public function down() {
        Schema::drop( 'article' );
    }
}