<?php namespace system\database\migrations;
use houdunwang\database\build\Migration;
use houdunwang\database\build\Blueprint;
use houdunwang\database\Schema;
class CreateModuleTable extends Migration {
    //执行
	public function up() {
		Schema::create( 'module', function ( Blueprint $table ) {
            $table->increments( 'id' );
            $table->char('itf', 20)->defaults('')->comment('模块标识');
            $table->char('name', 20)->defaults('')->comment('模块名称');
            $table->char('digest', 150)->defaults('')->comment('模块介绍');
            $table->tinyInteger('iswc')->unsigned()->defaults(0)->comment('是否处理微信');
            $table->tinyInteger('issy')->unsigned()->defaults(0)->comment('是否为系统模块');
            $table->tinyInteger('isrc')->unsigned()->defaults(0)->comment('是否回收');
        });
    }

    //回滚
    public function down() {
        Schema::drop( 'module' );
    }
}