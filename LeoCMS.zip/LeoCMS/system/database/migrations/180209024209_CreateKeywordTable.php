<?php namespace system\database\migrations;
use houdunwang\database\build\Migration;
use houdunwang\database\build\Blueprint;
use houdunwang\database\Schema;
class CreateKeywordTable extends Migration {
    //执行
	public function up() {
		Schema::create( 'keyword', function ( Blueprint $table ) {
			$table->increments( 'id' );
            $table->char('name', 50)->defaults('')->comment('关键词名称');
            $table->text('content')->comment('回复内容');
        });
    }

    //回滚
    public function down() {
        Schema::drop( 'keyword' );
    }
}