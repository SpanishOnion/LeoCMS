<?php namespace system\database\migrations;
use houdunwang\database\build\Migration;
use houdunwang\database\build\Blueprint;
use houdunwang\database\Schema;
class CreateCategoryTable extends Migration {
    //执行
	public function up() {
		Schema::create( 'category', function ( Blueprint $table ) {
			$table->increments( 'id' );
            $table->char('name', 20)->defaults('')->comment('分类名称');
            $table->char('dsc', 30)->defaults('')->comment('分类描述');
            $table->smallint('pid')->unsigned()->defaults(0)->comment('父级id');
        });
    }

    //回滚
    public function down() {
        Schema::drop( 'category' );
    }
}