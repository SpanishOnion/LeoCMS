<?php namespace system\database\seeds;
use houdunwang\database\build\Seeder;
use houdunwang\db\Db;
class ModuleTableSeeder extends Seeder {
    //执行
	public function up() {
		//Db::table('news')->insert(['title'=>'后盾人']);
        Db::table('module')->insert(['itf' => 'base', 'name' => '微信文本回复', 'digest' => '接收到用户发送至公众号的消息后，对其进行回复', 'iswc' => 1, 'issy' => 1, 'isrc' => 0]);
    }
    //回滚
    public function down() {

    }
}