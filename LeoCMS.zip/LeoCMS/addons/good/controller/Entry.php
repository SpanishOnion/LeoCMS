<?php
namespace addons\good\controller;
use houdunwang\view\View;
use module\LeoController;
class Entry extends LeoController {
    public function index(){
        View::make('');
    }
}