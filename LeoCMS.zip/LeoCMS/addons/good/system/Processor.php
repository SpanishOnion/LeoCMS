<?php
namespace addons\good\system;
use module\LeoProcessor;
class Processor extends LeoProcessor {
    public function handler(){
        //处理微信相关操作的默认方法
    }
}