<?php
namespace addons\tests\controller;
use module\LeoController;
class Entry extends LeoController {
    public function index(){
        //默认控制器的index方法
    }
}