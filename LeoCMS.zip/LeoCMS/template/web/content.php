<extend file='template/web/master'>
<block name="content">
    <div class="featured container">
        <div id="owl-demo" class="owl-carousel">
            <div class="item">
                <div class="zoom-container">
                    <div class="zoom-caption">
                        <span>Youtube</span>
                        <a href="<?php echo $tplPath; ?>single.html">
                            <i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
                        </a>
                        <p>Video's Name</p>
                    </div>
                    <img src="<?php echo $tplPath; ?>images/1.jpg">
                </div>
            </div>
            <div class="item">
                <div class="zoom-container">
                    <div class="zoom-caption">
                        <span>Youtube</span>
                        <a href="<?php echo $tplPath; ?>single.html">
                            <i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
                        </a>
                        <p>Video's Name</p>
                    </div>
                    <img src="<?php echo $tplPath; ?>images/2.jpg">
                </div>
            </div>
            <div class="item">
                <div class="zoom-container">
                    <div class="zoom-caption">
                        <span>Youtube</span>
                        <a href="<?php echo $tplPath; ?>single.html">
                            <i class="f fa fa-play-circle-o fa-5x"></i>
                        </a>
                        <p>Video's Name</p>
                    </div>
                    <img src="<?php echo $tplPath; ?>images/3.jpg">
                </div>
            </div>
            <div class="item">
                <div class="zoom-container">
                    <div class="zoom-caption">
                        <span>Youtube</span>
                        <a href="<?php echo $tplPath; ?>single.html">
                            <i class="f fa fa-play-circle-o fa-5x"></i>
                        </a>
                        <p>Video's Name</p>
                    </div>
                    <img src="<?php echo $tplPath; ?>images/8.jpg">
                </div>
            </div>
            <div class="item">
                <div class="zoom-container">
                    <div class="zoom-caption">
                        <span>Youtube</span>
                        <a href="<?php echo $tplPath; ?>single.html">
                            <i class="f fa fa-play-circle-o fa-5x"></i>
                        </a>
                        <p>Video's Name</p>
                    </div>
                    <img src="<?php echo $tplPath; ?>images/9.jpg">
                </div>
            </div>
            <div class="item">
                <div class="zoom-container">
                    <div class="zoom-caption">
                        <span>Youtube</span>
                        <a href="<?php echo $tplPath; ?>single.html">
                            <i class="f fa fa-play-circle-o fa-5x"></i>
                        </a>
                        <p>Video's Name</p>
                    </div>
                    <img src="<?php echo $tplPath; ?>images/10.jpg">
                </div>
            </div>
            <div class="item">
                <div class="zoom-container">
                    <div class="zoom-caption">
                        <span>Youtube</span>
                        <a href="<?php echo $tplPath; ?>single.html">
                            <i class="f fa fa-play-circle-o fa-5x"></i>
                        </a>
                        <p>Video's Name</p>
                    </div>
                    <img src="<?php echo $tplPath; ?>images/11.jpg">
                </div>
            </div>
            <div class="item">
                <div class="zoom-container">
                    <div class="zoom-caption">
                        <span>Youtube</span>
                        <a href="<?php echo $tplPath; ?>single.html">
                            <i class="f fa fa-play-circle-o fa-5x"></i>
                        </a>
                        <p>Video's Name</p>
                    </div>
                    <img src="<?php echo $tplPath; ?>images/12.jpg">
                </div>
            </div>
        </div>
    </div>
    <div id="page-content" class="single-page container">
        <div class="row">
            <div id="main-content" class="col-md-8">
                <div class="box">
                    <div class="line"></div>
                    <h4><?php echo $data['title']; ?></h4>
                    <div class="info">
                        <h5>By <?php echo $data['author']; ?></h5>
                        <span><i class="fa fa-calendar"></i><?php echo date('Y-m-d',$data['adtime']); ?></span>
                        <span><i class="fa fa-heart"></i><?php echo $data['click']; ?></span>
                    </div>
                    <?php echo $data['content']; ?>
                    <div class="line"></div>
                    <div class="comment">
                        <h3>Leave A Comment</h3>
                        <form name="form1" method="post" action="">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control input-lg" name="name" id="name" placeholder="Enter name" required="required" />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="email" class="form-control input-lg" name="email" id="email" placeholder="Enter email" required="required" />
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
										<textarea name="message" id="message" class="form-control" rows="4" cols="25" required="required" placeholder="Message"></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-4 btn-block" name="btnBooking" id="btnBbooking">Book Now</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="box">
                    <div class="box-header header-natural">
                        <h2>RELATED VIDEOS</h2>
                    </div>
                    <div class="box-content">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="wrap-vid">
                                    <div class="zoom-container">
                                        <div class="zoom-caption">
                                            <span>Youtube</span>
                                            <a href="<?php echo $tplPath; ?>single.html">
                                                <i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
                                            </a>
                                            <p>Video's Name</p>
                                        </div>
                                        <img src="<?php echo $tplPath; ?>images/2.jpg">
                                    </div>
                                    <h3 class="vid-name"><a href="<?php echo $tplPath; ?>#">Video's Name</a></h3>
                                    <div class="info">
                                        <h5>By <a href="<?php echo $tplPath; ?>#">Kelvin</a></h5>
                                        <span><i class="fa fa-calendar"></i>25/3/2015</span>
                                        <span><i class="fa fa-heart"></i>1,200</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="wrap-vid">
                                    <div class="zoom-container">
                                        <div class="zoom-caption">
                                            <span>Youtube</span>
                                            <a href="<?php echo $tplPath; ?>single.html">
                                                <i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
                                            </a>
                                            <p>Video's Name</p>
                                        </div>
                                        <img src="<?php echo $tplPath; ?>images/2.jpg">
                                    </div>
                                    <h3 class="vid-name"><a href="<?php echo $tplPath; ?>#">Video's Name</a></h3>
                                    <div class="info">
                                        <h5>By <a href="<?php echo $tplPath; ?>#">Kelvin</a></h5>
                                        <span><i class="fa fa-calendar"></i>25/3/2015</span>
                                        <span><i class="fa fa-heart"></i>1,200</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="wrap-vid">
                                    <div class="zoom-container">
                                        <div class="zoom-caption">
                                            <span>Youtube</span>
                                            <a href="<?php echo $tplPath; ?>single.html">
                                                <i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
                                            </a>
                                            <p>Video's Name</p>
                                        </div>
                                        <img src="<?php echo $tplPath; ?>images/2.jpg">
                                    </div>
                                    <h3 class="vid-name"><a href="<?php echo $tplPath; ?>#">Video's Name</a></h3>
                                    <div class="info">
                                        <h5>By <a href="<?php echo $tplPath; ?>#">Kelvin</a></h5>
                                        <span><i class="fa fa-calendar"></i>25/3/2015</span>
                                        <span><i class="fa fa-heart"></i>1,200</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="sidebar" class="col-md-4">
                <!---- Start Widget ---->
                <div class="widget wid-follow">
                    <div class="heading"><h4>Follow Us</h4></div>
                    <div class="content">
                        <ul class="list-inline">
                            <li>
                                <a href="<?php echo $tplPath; ?>facebook.com/">
                                    <div class="box-facebook">
                                        <span class="fa fa-facebook fa-2x icon"></span>
                                        <span>1250</span>
                                        <span>Fans</span>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo $tplPath; ?>facebook.com/">
                                    <div class="box-twitter">
                                        <span class="fa fa-twitter fa-2x icon"></span>
                                        <span>1250</span>
                                        <span>Fans</span>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo $tplPath; ?>facebook.com/">
                                    <div class="box-google">
                                        <span class="fa fa-google-plus fa-2x icon"></span>
                                        <span>1250</span>
                                        <span>Fans</span>
                                    </div>
                                </a>
                            </li>
                        </ul>
                        <img src="<?php echo $tplPath; ?>images/banner.jpg">
                    </div>
                </div>
                <!---- Start Widget ---->
                <div class="widget wid-post">
                    <div class="heading"><h4>Category</h4></div>
                    <div class="content">
                        <div class="post wrap-vid">
                            <div class="zoom-container">
                                <div class="zoom-caption">
                                    <span>Youtube</span>
                                    <a href="<?php echo $tplPath; ?>single.html">
                                        <i class="f fa fa-play-circle-o fa-5x"></i>
                                    </a>
                                    <p>Video's Name</p>
                                </div>
                                <img src="<?php echo $tplPath; ?>images/1.jpg">
                            </div>
                            <div class="wrapper">
                                <h5 class="vid-name"><a href="<?php echo $tplPath; ?>#">Video's Name</a></h5>
                                <div class="info">
                                    <h6>By <a href="<?php echo $tplPath; ?>#">Kelvin</a></h6>
                                    <span><i class="fa fa-calendar"></i>25/3/2015</span>
                                    <span><i class="fa fa-heart"></i>1,200</span>
                                </div>
                            </div>
                        </div>
                        <div class="post wrap-vid">
                            <div class="zoom-container">
                                <div class="zoom-caption">
                                    <span>Youtube</span>
                                    <a href="<?php echo $tplPath; ?>single.html">
                                        <i class="f fa fa-play-circle-o fa-5x"></i>
                                    </a>
                                    <p>Video's Name</p>
                                </div>
                                <img src="<?php echo $tplPath; ?>images/2.jpg" />
                            </div>
                            <div class="wrapper">
                                <h5 class="vid-name"><a href="<?php echo $tplPath; ?>#">Video's Name</a></h5>
                                <div class="info">
                                    <h6>By <a href="<?php echo $tplPath; ?>#">Kelvin</a></h6>
                                    <span><i class="fa fa-calendar"></i>25/3/2015</span>
                                    <span><i class="fa fa-heart"></i>1,200</span>
                                </div>
                            </div>
                        </div>
                        <div class="post wrap-vid">
                            <div class="zoom-container">
                                <div class="zoom-caption">
                                    <span>Youtube</span>
                                    <a href="<?php echo $tplPath; ?>single.html">
                                        <i class="f fa fa-play-circle-o fa-5x"></i>
                                    </a>
                                    <p>Video's Name</p>
                                </div>
                                <img src="<?php echo $tplPath; ?>images/3.jpg">
                            </div>
                            <div class="wrapper">
                                <h5 class="vid-name"><a href="<?php echo $tplPath; ?>#">Video's Name</a></h5>
                                <div class="info">
                                    <h6>By <a href="<?php echo $tplPath; ?>#">Kelvin</a></h6>
                                    <span><i class="fa fa-calendar"></i>25/3/2015</span>
                                    <span><i class="fa fa-heart"></i>1,200</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!---- Start Widget ---->
                <div class="widget ">
                    <div class="heading"><h4>Top News</h4></div>
                    <div class="content">
                        <div class="wrap-vid">
                            <div class="zoom-container">
                                <div class="zoom-caption">
                                    <span>Youtube</span>
                                    <a href="<?php echo $tplPath; ?>single.html">
                                        <i class="f fa fa-play-circle-o fa-5x"></i>
                                    </a>
                                    <p>Video's Name</p>
                                </div>
                                <img src="<?php echo $tplPath; ?>images/1.jpg" />
                            </div>
                            <h3 class="vid-name"><a href="<?php echo $tplPath; ?>#">Video's Name</a></h3>
                            <div class="info">
                                <h5>By <a href="<?php echo $tplPath; ?>#">Kelvin</a></h5>
                                <span><i class="fa fa-calendar"></i>25/3/2015</span>
                                <span><i class="fa fa-heart"></i>1,200</span>
                            </div>
                        </div>
                        <div class="wrap-vid">
                            <div class="zoom-container">
                                <div class="zoom-caption">
                                    <span>Youtube</span>
                                    <a href="<?php echo $tplPath; ?>single.html">
                                        <i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
                                    </a>
                                    <p>Video's Name</p>
                                </div>
                                <img src="<?php echo $tplPath; ?>images/2.jpg">
                            </div>
                            <h3 class="vid-name"><a href="<?php echo $tplPath; ?>#">Video's Name</a></h3>
                            <div class="info">
                                <h5>By <a href="<?php echo $tplPath; ?>#">Kelvin</a></h5>
                                <span><i class="fa fa-calendar"></i>25/3/2015</span>
                                <span><i class="fa fa-heart"></i>1,200</span>
                            </div>
                        </div>
                        <div class="wrap-vid">
                            <div class="zoom-container">
                                <div class="zoom-caption">
                                    <span>Youtube</span>
                                    <a href="<?php echo $tplPath; ?>single.html">
                                        <i class="f fa fa-play-circle-o fa-5x"></i>
                                    </a>
                                    <p>Video's Name</p>
                                </div>
                                <img src="<?php echo $tplPath; ?>images/3.jpg">
                            </div>
                            <h3 class="vid-name"><a href="<?php echo $tplPath; ?>#">Video's Name</a></h3>
                            <div class="info">
                                <h5>By <a href="<?php echo $tplPath; ?>#">Kelvin</a></h5>
                                <span><i class="fa fa-calendar"></i>25/3/2015</span>
                                <span><i class="fa fa-heart"></i>1,200</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</block>
