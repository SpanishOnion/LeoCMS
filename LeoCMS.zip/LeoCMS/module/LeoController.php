<?php namespace module;
use app\common\controller\AdminBase;
use app\home\controller\Entry;

class LeoController extends AdminBase
{
    public function display($v = [])
    {
       return view(Entry::$m, $v);
    }
}