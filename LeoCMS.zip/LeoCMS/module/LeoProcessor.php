<?php
namespace module;

use houdunwang\route\Controller;

class LeoProcessor extends Controller
{

}