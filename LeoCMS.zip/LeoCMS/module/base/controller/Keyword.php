<?php namespace module\base\controller;
use module\LeoController;
use system\model\Keyword as m;

/**
 * Class Keyword
 * @package module\base\controller 系统模块
 */
class Keyword extends LeoController
{
    public function custom()
    {
        $data = m::get();
        echo $this->display(['data' => $data ? $data->toArray() : []]);
    }

    public function saveKw()
    {
        if(IS_POST) echo (new m)->save($_POST)['id'];
    }

    public function system()
    {
        $data = m::get();
        echo $this->display(['data' => $data ? $data->toArray() : []]);
    }
}