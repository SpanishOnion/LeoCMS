<extend file='./resource/view/admin/wechat-master'/>
<block name="content">
    <div class="form-list container form-list-main">
        <div class="alert headInfo atcHead">
            <button class="btn btn-info" id="kw-add">添加关键词</button>
        </div>
        <div class="list-article">
            <table class="table table-hover">
                <tbody id="tb">
                    <tr>
                        <th>序号</th>
                        <th>关键词</th>
                        <th>回复内容</th>
                        <th>操作</th>
                    </tr>
                    <?php foreach($data as $k=>$v){ ?>
                    <tr data-id="<?php echo $v['id']; ?>">
                        <td><?php echo $k + 1; ?></td>
                        <td><?php echo $v['name']; ?></td>
                        <td><?php echo $v['content']; ?></td>
                        <td>
                            <button class="btn btn-success btn-xs edt-btn">编辑该关键词</button>
                            <button class="btn btn-off btn-xs del-btn">删除该关键词</button>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
            <hr>
        </div>
        <form id="form">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">关键词</label>
                        <div class="col-sm-9">
                            <input class="form-control" id="name" name="name" type="text" placeholder="请输入关键词">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">回复内容</label>
                        <div class="col-sm-9">
                            <textarea class="form-control" id="content" name="content" type="text"  placeholder="请输入回复内容"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label"></label>
                        <button class="btn btn-info btn-sub" id="btn-sub" type="button">立刻保存</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</block>