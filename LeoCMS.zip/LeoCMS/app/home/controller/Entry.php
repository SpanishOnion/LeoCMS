<?php namespace app\home\controller;
use houdunwang\route\Controller;
use houdunwang\db\Db;
use houdunwang\request\Request;
use houdunwang\view\View;
use system\model\Article;
use system\model\Category;

class Entry extends Controller
{
    public static $m;
    private static $tpl;
    private static $a = ['id', 'title', 'click', 'author', 'adtime', 'thumb', 'digest'];

    public function __construct()
    {
        Middleware::set('install');
        self::$tpl = 'template/' . (IS_MOBILE ? 'mobile' : 'web/');
        $cate = Category::field(['id', 'name'])->get();
        View::with([
            'tplPath' => __ROOT__ . '/' . self::$tpl,
            'cate' => $cate ? $cate->toArray() : []
        ]);
    }

    public function index()
    {
        if (!empty($_GET['a'])) {
            $s = explode('/', $_GET['a']);
            if (is_dir('./addons/' . $s[0])) {
                $m = 'addons';
            } else if (is_dir('./module/' . $s[0])) {
                $m = 'module';
            } else {
                die;
            }
            $a = "\\" . $m . "\\" . $s[0] . "\\controller\\" . ucfirst($s[1]);
            self::$m = './' . $m . '/' . $s[0] . '/template/' . $s[1] . '/' . $s[2] . '.php';
            call_user_func([new $a, $s[2]], []);
            die;
        }
        $db = Db::table('article');
        return View::with([
            'ac' => 0,
            'first' => $db->field(self::$a)->find(1),
            'click' => $db->field(self::$a)->orderBy('click', 'DESC')->limit(2)->get(),
            'cateList' => $db->join('category', 'article.cid', '=', 'category.id')->field(['article.id','title','click','adtime','name','thumb','digest'])->where('recycle', '=', 0)->limit(5)->orderBy('article.id','DESC')->get()
        ])->make(self::$tpl . 'index.php');
    }

    public function archive()
    {
        $get = Request::get();
        $s = $get['search'];
        $w = [['recycle', 0], [$s ? ['title', 'like', "%$s%"] : ['cid', $get['id']]]];
        return View::with([
            'ac' => 1,
            'data' => Article::field(self::$a)->where($w)->get()
        ])->make(self::$tpl . 'archive.php');
    }

    public function content()
    {
        $id = Request::get('id');
        if (is_numeric($id)) {
            Article::where('id', $id)->increment('click', 1);
            return View::with([
                'ac' => 2,
                'data'=> Article::field(['title', 'author', 'adtime', 'cid', 'digest', 'click', 'content'])->find($id)->toArray()
            ])->make(self::$tpl . 'content.php');
        } else {
            $this->index();
        }
    }
}