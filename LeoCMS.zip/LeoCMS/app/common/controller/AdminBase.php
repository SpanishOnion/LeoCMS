<?php namespace app\common\controller;

use houdunwang\middleware\Middleware;
use houdunwang\route\Controller;
use houdunwang\view\View;
use system\model\Module;

class AdminBase extends Controller{
    //动作
    public function __construct()
    {
        Middleware::set('install');
        Middleware::set('sign');
        $s = explode('/', isset($_GET['s']) ? $_GET['s'] : $_GET['a']);
        v('mo', $s[0]);
        v('co', $s[1]);
        v('ac', $s[2]);
        View::with(['vnData' => Module::where('issy', 0)->where('isrc', 1)->get()]);
    }
}