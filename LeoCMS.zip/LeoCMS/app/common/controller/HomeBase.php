<?php namespace app\common\controller;


use houdunwang\view\View;

class HomeBase extends Controller{
    //动作
    public function __construct()
    {
        Middleware::set('install');
    }
}