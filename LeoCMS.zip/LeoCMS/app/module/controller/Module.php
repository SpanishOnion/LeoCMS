<?php namespace app\module\controller;

use app\common\controller\AdminBase;
use houdunwang\dir\Dir;
use \system\model\Module as m;

class Module extends AdminBase {

    public function index()
    {
        return View::with(['data' => m::where('issy', 0)->get()])->make();
    }

    public function design()
    {
        if (IS_POST && isset($_POST['itf']) && $_POST['itf'] != '') {
            $itf = $_POST['itf'];
            if (is_dir('addons/' . $itf) || is_dir('module' . $itf)) {
                echo '';
            } else {
                Dir::create('addons/' . $itf . '/controller');
                Dir::create('addons/' . $itf . '/model');
                Dir::create('addons/' . $itf . '/template');
                Dir::create('addons/' . $itf . '/system');
                $coStr =
<<<EOT
<?php
namespace addons\\{$itf}\controller;
use module\LeoController;
class Entry extends LeoController {
    public function index(){
        //默认控制器的index方法
    }
}
EOT;
                file_put_contents('addons/' . $itf . '/controller/Entry.php', $coStr);
                if (isset($_POST['iswc'])) {
                    $pcStr =
<<<EOT
<?php
namespace addons\\{$itf}\system;
use module\LeoProcessor;
class Processor extends LeoProcessor {
    public function handler(){
        //处理微信相关操作的默认方法
    }
}
EOT;
                    file_put_contents('addons/' . $itf . '/system/Processor.php', $pcStr);
                }
                echo (new m)->save($_POST)['id'];
            }
        }
    }

    public function togIst()
    {
        if (IS_POST && $_POST['id'] && $_POST['id'] !== '') {
            m::find($_POST['id'])->save(['isrc' => $_POST['ac']]);
            echo '';
        }
    }

    public function del()
    {
        if (IS_POST && $_POST['id'] && $_POST['id'] !== '') {
            Dir::del('./addons/' . $_POST['itf']);
            echo m::delete($_POST['id']);
        }
    }
}