<extend file='ROOT_PATH/resource/view/admin/master'/>
<block name="content">
    <div class="form-list container form-list-main">
        <div class="alert headInfo atcHead">
            <div class="alllog" ><button class="btn btn-info btn-addAtc" id="design">设计功能模块</button></div>
        </div>
        <div class="list-article">
            <table class="table table-hover">
                <tbody id="tb">
                    <tr>
                        <th>序号</th>
                        <th>模块标识</th>
                        <th>模块名称</th>
                        <th>操作</th>
                    </tr>
                    <?php foreach($data as $k=>$v){ ?>
                    <tr data-id="<?php echo $v['id']; ?>">
                        <td><?php echo $k + 1; ?></td>
                        <td><?php echo $v['itf']; ?></td>
                        <td><?php echo $v['name']; ?></td>
                        <td>
                            <?php if($v['isrc'] == 0){ ?>
                            <button class="btn btn-success btn-xs ist-btn">安装此模块</button>
                            <?php } else { ?>
                            <button class="btn btn-danger btn-xs uni-btn">卸载此模块</button>
                            <?php } ?>
                            <button class="btn btn-off btn-xs del-btn">彻底删除此模块</button>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
            <hr>
        </div>

        <form id="form">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">模块标识</label>
                        <div class="col-sm-9">
                            <input class="form-control" name="itf" type="text" placeholder="请输入模块标识">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">模块名称</label>
                        <div class="col-sm-9">
                            <input class="form-control" name="name" type="text" value="" placeholder="请输入模块名称">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">模块描述</label>
                        <div class="col-sm-9">
                            <textarea class="form-control" id="digest" type="text"  placeholder="请输入模块描述"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">微信处理</label>
                        <div class="col-sm-9">
                            <input class="form-control form-cb" name="iswc" type="checkbox" value="1">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label"></label>
                        <button class="btn btn-info btn-sub" id="btn-sub" type="button">立刻保存</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</block>