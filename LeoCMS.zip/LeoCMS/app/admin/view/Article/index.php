<extend file='resource/view/admin/master'/>
<block name="content">
    <div class="form-list container form-list-main">
        <div class="alert headInfo atcHead">
            <div class="alllog" >
                <button class="btn btn-info btn-addAtc btn-atc">添加文章</button>
            </div>
        </div>

        <div class="list-article">
            <table class="table table-hover">
                <tr>
                    <th>序号</th>
                    <th>文章标题</th>
                    <th>文章作者</th>
                    <th>所属分类</th>
                    <th>修改时间</th>
                    <th>发布时间</th>
                    <th>点击量</th>
                    <th>操作</th>
                </tr>
                <?php foreach($data as $k=>$v){ ?>
                <tr data-id="<?php echo $v['id']; ?>">
                    <td><?php echo $k + 1; ?></td>
                    <td><?php echo $v['title']; ?></td>
                    <td><?php echo $v['author']; ?></td>
                    <td><?php echo $v['name']; ?></td>
                    <td><?php echo $v['uptime'] ? date('Y-m-d H:i:s', $v['uptime']) : '暂未修改'; ?></td>
                    <td><?php echo date('Y-m-d H:i:s', $v['adtime']); ?></td>
                    <td><?php echo $v['click']; ?></td>
                    <td>
                        <button class="btn btn-success btn-xs edAtc">编辑此篇文章</button>
                        <button class="btn btn-danger btn-xs delRec">删除至回收站</button>
                    </td>
                </tr>
                <?php } ?>
            </table>
            <hr>
        </div>

        <form action="">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">文章标题</label>
                        <div class="col-sm-9">
                            <input class="form-control" name="title" type="text" placeholder="文章标题">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">文章作者</label>
                        <div class="col-sm-9">
                            <input class="form-control" name="author" type="text" value="李聪">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">所属分类</label>
                        <div class="col-sm-9">
                            <select class="js-example-basic-single form-control" name="cid">
                                <option value="0">请选择分类</option>
                                <?php foreach($cgyData as $k=>$v) { ?>
                                <option value="<?php echo $v['id']; ?>"><?php echo $v['_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">缩略图</label>
                        <!-- 单图上传 -->
                        <div class="col-sm-9">
                            <div class="input-group">
                                <input class="form-control" name="thumb" type="text" readonly="">
                                <div class="input-group-btn">
                                    <button class="btn btn-default upImage" type="button">选择图片</button>
                                </div>
                            </div>
                            <div class="input-group" style="margin-top:5px;">
                                <img class="img-responsive img-thumbnail" src="<?php echo __ROOT__; ?>/resource/images/default.jpg">
                                <em class="rm-img" title="删除这张图片">×</em>
                            </div>
                            <span class="help-block">建议大小(宽100高100)</span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">文章摘要</label>
                        <div class="col-sm-9">
                            <textarea class="form-control" name="digest" type="text"  placeholder="文章摘要"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for=""  class="col-sm-2 control-label">文章内容</label>
                        <div class="col-sm-9">
                            <!-- KindEditor -->
                            <textarea id="editor_id" name="content" style="width:795px"></textarea>
                            <input type="hidden" class="hidden" name="content">
                        </div>
                    </div>
                </div>
            </div>
            <button class="btn btn-info funBtn subBtn" type="button">立刻发布</button>
        </form>
    </div>
</block>