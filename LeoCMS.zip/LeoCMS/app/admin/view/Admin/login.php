<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>login</title>
		<link rel="stylesheet" href="./resource/css/admin/login/normalize.css">
		<link rel="stylesheet" href="./resource/css/admin/login/demo.css">
		<!--必要样式-->
		<link rel="stylesheet" href="./resource/css/admin/login/component.css">
	</head>
	<body>
		<div class="container demo-1">
			<div class="content">
				<div class="large-header" id="large-header">
					<canvas id="demo-canvas"></canvas>
					<div class="logo_box">
						<h2><span class="title">LeoCMS</span>后台管理系统</h2>
                        <div class="input_outer">
                            <span class="u_user"></span>
                            <input class="text" name="username" type="text" value="" placeholder="请输入账户">
                        </div>
                        <div class="input_outer">
                            <span class="us_uer"></span>
                            <input class="text" name="password" type="password" value="" placeholder="请输入密码">
                        </div>
                        <div class="input_outer">
                            <span class="us_uer"></span>
                            <input class="text" name="code" type="text" value="" placeholder="请输入验证码">
                            <img class="code" src="index.php?s=admin/Admin/code">
                        </div>
                        <div class="mb2"><button class="act-but submit" type="button">立 即 登 录</button></div>
					</div>
				</div>
			</div>
		</div>
		<script src="./resource/js/admin/login/TweenLite.min.js"></script>
		<script src="./resource/js/admin/login/EasePack.min.js"></script>
		<script src="./resource/js/admin/login/rAF.js"></script>
		<script src="./resource/js/admin/login/demo-1.js"></script>
        <script src="./resource/js/common/helper.js"></script>
        <script src="./resource/js/admin/login/index.js"></script>
        <!--[if IE]>
        <script src="./resource/js/admin/login/html5.js"></script>
        <![endif]-->
	</body>
</html>