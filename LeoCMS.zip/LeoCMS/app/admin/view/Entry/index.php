<extend file='ROOT_PATH/resource/view/admin/master'/>
<block name="content">
    <div class="form-list container form-list-main">
        <div class="alert headInfo">欢迎来到LeoCMS后台管理系统!</div>
        <table id="MyStretchGrid" class="table table-striped datagrid m-b-sm">
            <thead><tr><th></th><th></th></tr></thead>
            <tbody>
            <tr>
                <td>操作系统 ：</td>
                <td><?php echo PHP_OS ?></td>
            </tr>
            <tr>
                <td>PHP版本 ：</td>
                <td><?php echo PHP_VERSION ?></td>
            </tr>
            <tr>
                <td>核心框架 ：</td>
                <td><?php echo HDPHP_VERSION ?></td>
            </tr>
            <tr>
                <td>项目版本 ：</td>
                <td>1.0.0</td>
            </tr>
            <tr>
                <td>项目时间 ：</td>
                <td>2018年02月01日08:30:00</td>
            </tr>
            <tr>
                <td>项目作者 ：</td>
                <td>李聪(Leo)</td>
            </tr>
            <tr>
                <td>Tel:</td>
                <td>18141909876</td>
            </tr>
            </tbody>
        </table>
    </div>
</block>