<extend file='ROOT_PATH/resource/view/admin/master'/>
<block name="content">
    <div class="form-list container form-list-main">
        <div class="alert headInfo atcHead">
            <div class="alllog" >
                <button class="btn btn-default" id="backup">
                    <svg class="icon" aria-hidden="true" style="font-size:20px">
                        <use xlink:href="#icon-yunduanbeifen"></use>
                    </svg>
                    <span>一键备份数据库</span>
                </button>
            </div>
        </div>
        <table class="table table-hover">
            <tbody id="tbd">
                <tr>
                    <th>序号</th>
                    <th>备份数据所在目录</th>
                    <th>备份时间</th>
                    <th>操作</th>
                </tr>
                <?php foreach($data as $k=>$v){ ?>
                    <tr data-id="">
                        <td><?php echo $k + 1; ?></td>
                        <td><?php echo __ROOT__, '/' ;?><span><?php echo 'backup/', $v['filename']; ?></span></td>
                        <td><?php echo date('Y-m-d H:i:s', $v['filemtime']);?></td>
                        <td>
                            <button class="btn btn-success btn-xs rdc">一键恢复</button>
                            <button class="btn btn-danger btn-xs del">删除备份数据</button>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <hr>
    </div>
    <!--添加账号表单-->
    <div class="modelFrames">
        <div class="modelFrame frames-small">
            <div class="form-group">
                <label>管理员昵称</label>
                <input class="form-control" name="nickname" type="text" value="">
            </div>
            <div class="form-group">
                <label>管理员账号</label>
                <input class="form-control" name="username" type="text" value="">
            </div>
            <div class="form-group">
                <label>管理员密码</label>
                <input class="form-control skip" name="password" type="password" value="">
            </div>
            <input class="form-control addTime" name="ltime" type="hidden" value="">
            <button class="btn btn-info btn-block btn-ajax-edit">立刻添加</button>
            <button class="btn btn-block btn-cancel">取消</button>
        </div>
        <div class="mask"></div>
    </div>

    <!--修改密码表单-->
    <div class="modelFrames">
        <div class="modelFrame frames-small">
            <div class="form-group">
                <label>管理员账号</label>
                <input class="form-control" name="username" type="text" value="">
            </div>
            <div class="form-group">
                <label>管理员密码</label>
                <input class="form-control skip" name="password" type="password" value="">
            </div>
            <div class="form-group">
                <label>管理员密码</label>
                <input class="form-control skip" name="password" type="password" value="">
            </div>
            <div class="form-group">
                <label>所属分类</label>
                <select class="form-control" name="cid">
                    <option value="">请选择所属分类</option>
                    <option value="">顶级分类</option>
                </select>
            </div>
            <input class="form-control addTime" name="ltime" type="hidden" value="">
            <button class="btn btn-info btn-block btn-ajax-edit">立刻添加</button>
            <button class="btn btn-block btn-cancel">取消</button>
        </div>
        <div class="mask"></div>
    </div>
</block>