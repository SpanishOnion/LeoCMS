<extend file='ROOT_PATH/resource/view/admin/master'/>
<block name="content">
    <div class="form-list container form-list-main">
        <form action="" style="display: block;">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">网站标题</label>
                        <div class="col-sm-9">
                            <input class="form-control" name="title" type="text" placeholder="文章标题" value="李聪 · 个人博客">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">备案号</label>
                        <div class="col-sm-9">
                            <input class="form-control" name="author" type="text" value="京ICP备17011914号">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">网站logo</label>
                        <!-- 单图上传 -->
                        <div class="col-sm-9">
                            <div class="input-group">
                                <input class="form-control" name="thumb" type="text" readonly="" value="<?php echo __ROOT__; ?>/favicon.ico">
                                <div class="input-group-btn">
                                    <button class="btn btn-default upImage" type="button">选择图片</button>
                                </div>
                            </div>
                            <div class="input-group" style="margin-top:5px;">
                                <img class="img-responsive img-thumbnail" style="width:125px;height:125px;" src="<?php echo __ROOT__; ?>/favicon.ico">
                                <em class="rm-img" title="删除这张图片">×</em>
                            </div>
                            <span class="help-block">建议大小(宽100高100)</span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">网站关键词</label>
                        <div class="col-sm-9">
                            <textarea class="form-control" name="digest" type="text"  placeholder="文章摘要"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for=""  class="col-sm-2 control-label">网站描述</label>
                        <div class="col-sm-9">
                            <textarea name="content" style="width:795px"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for=""  class="col-sm-2 control-label"></label>
                        <button class="btn btn-info funBtn subBtn" type="button" style="margin-left:15px">立刻保存</button>
                    </div>
                </div>
            </div>

        </form>
    </div>
</block>