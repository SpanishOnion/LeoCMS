<?php namespace app\admin\controller;
use app\common\controller\AdminBase;
use houdunwang\backup\Backup;
use houdunwang\view\View;

class Entry extends AdminBase
{
    public function index()
    {
        return View::make();
    }

    public function config()
    {
        return View::make();
    }

    public function dataList()
    {
        return View::with(['data' => Backup::getBackupDir('backup')])->make();
    }

    /**
     * backup备份数据
     * size [分卷大小单位KB]
     * dir [备份文件所在目录]
     */
    public function backup() {
        $status = Backup::backup(['size' => 200, 'dir'  => 'backup/' . date('Ymdhis')], function ($result) {
            echo json_encode(['s' => $result['status'] == 'run' ? 1 : 0, 'msg' =>$result['message']]);
        });
        if ( $status === false ) echo json_encode(['s' => 0, 'msg' => Backup::getError()]);
    }

    /**
     * recovery还原数据
     * dir [还原数据所在目录]
     */
    public function recovery() {
        //要还原的备份目录
        $status = Backup::recovery(['dir' => $_POST['path']], function ($result) {
            echo json_encode(['s' => $result['status'] == 'run' ? 1 : 0, 'msg' =>$result['message']]);
        });
        if ($status === false) echo json_encode(['s' => 0, 'msg' => Backup::getError()]);
    }
}