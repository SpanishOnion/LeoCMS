<?php namespace app\admin\controller;

use app\common\controller\AdminBase;
use system\model\Admin;

class User extends AdminBase
{
    public function index()
    {
        $admin = Admin::get();
        return View::with(['data' => $admin ? $admin->toArray() : []])->make();
    }

    public function del()
    {
        if(IS_POST && isset($_POST['id']) && $_POST['id'] !== '') echo Admin::delete($_POST['id']);

    }

    public function edit()
    {
        if(IS_POST && isset($_POST['id'])) {
            if($_POST['id'] === '') {
                unset($_POST['id']);
                $id = (new Admin)->save($_POST)->toArray()['id'];
                echo $id ? json_encode(['type' => 0, 'id' => $id]) : 0;
            }
        }
    }
}