<?php namespace app\admin\controller;

use app\common\controller\AdminBase;

class Photo extends AdminBase
{
    public function index(){
        return View::make();
    }
}
