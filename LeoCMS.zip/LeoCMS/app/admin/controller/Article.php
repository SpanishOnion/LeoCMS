<?php namespace app\admin\controller;

use app\common\controller\AdminBase;
use houdunwang\db\Db;
use houdunwang\view\View;
use system\model\Category;
use system\model\Article as m;

class Article extends AdminBase {

    /**
     * @return mixed object 载入文章列表页视图并分别分配文章列表数据与分类数据
     */
    public function index()
    {
        $cgy = Category::get();
        return View::with([
            'data' => Db::table('article')->join('category', 'article.cid', '=', 'category.id')->field(['article.id','title','author','click','adtime','uptime','name'])->where('recycle', '=', 0)->get(),
            'cgyData' => Arr::tree($cgy ? $cgy->toArray() : [], 'name', 'id', 'pid')
        ])->make();
    }

    /**
     * @return mixed object 载入回收站视图并分配文章列表数据
     */
    public function recycle()
    {
        return View::with(['data' => $data = Db::table('article')->join('category', 'article.cid', '=', 'category.id')->field(['article.id','title','author','click','adtime','uptime','name'])->where('recycle', '=', 1)->get()])->make();
    }

    /**
     * 文章的AJAX添加 & 编辑
     */
    public function edit()
    {
        if(IS_POST && isset($_POST['id'])) {
            if($_POST['id'] === '') {
                unset($_POST['id']);
                $_POST['adtime'] = time();
                $id = (new m)->save($_POST)->toArray()['id'];
                echo $id ? json_encode(['type' => 0, 'id' => $id, 'time' => date('Y-m-d H:i:s', $_POST['adtime']), 'name' => Category::field('name')->find($_POST['cid'])->toArray()['name']]) : 0;
            } else {
                $_POST['uptime'] = time();
                (m::find($_POST['id']))->save($_POST);
                echo json_encode(['type' => 1, 'time' => date('Y-m-d H:i:s', $_POST['uptime'])]);
            }
        }
    }

    /**
     * AJAX获取指定文章数据
     */
    public function get()
    {
        if(IS_POST && isset($_POST['id']) && $_POST['id'] !== '') echo json_encode(m::field(['title', 'author', 'cid', 'digest', 'content', 'thumb'])->find($_POST['id'])->toArray());
    }

    /**
     * AJAX加入回收站
     */
    public function toRcc()
    {
        if(IS_POST && isset($_POST['id']) && $_POST['id'] !== ''){
            (m::find($_POST['id']))->save(['recycle' => 1]);
            echo 1;
        }
    }

    /**
     * AJAX Reduction还原数据
     */
    public function rdcRcc()
    {
        if(IS_POST && isset($_POST['id']) && $_POST['id'] !== ''){
            (m::find($_POST['id']))->save(['recycle' => 0]);
            echo 1;
        }
    }

    /**
     * 彻底删除数据 可批量删除, 只需要在id中保存一个数组过来即可
     */
    public function del()
    {
        if(IS_POST && isset($_POST['id']) && $_POST['id'] !== ''){
            echo m::delete($_POST['id']);
        }
    }
}