<?php namespace app\admin\controller;

use app\common\controller\AdminBase;
use hdphp\arr\Arr;
use system\model\Category as m;

class Category extends AdminBase
{
    public function index(){
        $data = m::get();
        return View::with(['data' => $data ? Arr::tree($data->toArray(), 'name', 'id', 'pid') : []])->make();
    }

    public function edit() {
        if(IS_POST && isset($_POST['id'])) {
            if($_POST['id'] === '') {
                unset($_POST['id']);
                $id = (new m)->save($_POST)->toArray()['id'];
                echo $id ? json_encode(['type' => 0, 'id' => $id]) : 0;
            } else {
                (m::find($_POST['id']))->save($_POST);
                echo json_encode(['type' => 1]);
            }
        }
    }

    public function del()
    {
        if(IS_POST && isset($_POST['id']) && $_POST['id'] !== '') echo m::delete($_POST['id']);
    }

    public function getCate()
    {
        if(IS_POST && isset($_POST['id']) && $_POST['id'] !== '') echo json_encode(m::getCateData($_POST['id']));
    }
}