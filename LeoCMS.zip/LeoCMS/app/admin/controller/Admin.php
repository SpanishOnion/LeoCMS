<?php namespace app\admin\controller;

use houdunwang\code\Code;
use houdunwang\route\Controller;
use houdunwang\session\Session;
use system\model\Admin as m;

class Admin extends Controller
{
    public function login() {
        return View::make();
    }

    public function code() {
        Code::make();
    }

    public function check() {
        if(IS_POST) {
            m::check();
        }
    }

    public function signOut()
    {
        Session::del('cmsAdmin');
        return redirect('admin.Admin.login');
    }
}