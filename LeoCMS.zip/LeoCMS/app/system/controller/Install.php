<?php namespace app\system\controller;

use houdunwang\database\Schema;
use houdunwang\route\Controller;
use houdunwang\view\View;

class Install extends Controller{

    public function __construct()
    {
        if(is_file('./lock.php')) return View::make('./app/system/view/Install/completed.html');
    }

    public function copyright()
    {
        return View::make();
    }

    public function environmental()
    {
        return View::make();
    }

    public function database()
    {
        return View::make();
    }

    /**
     * cnDb测试连接数据库 连接失败则返回错误信息
     */
    public function cnDb()
    {
        if (IS_POST) {
            try {
                new \PDO('mysql:host=' . $_POST['host'] . ';dbname=' . $_POST['database'], $_POST['user'], $_POST['password']);
                file_put_contents('./.env',<<<EOF
APP_NAME=HDPHP 3.0
DB_DRIVER=mysql
DB_HOST={$_POST['host']}
DB_DATABASE={$_POST['database']}
DB_USER={$_POST['user']}
DB_PASSWORD={$_POST['password']}
EOF
                );
                echo '';
            } catch (\PDOException $e) {
                header('Content-type: text/html;charset=gbk');
                echo $e->getMessage();
            }
        }
    }

    /**
     * finish完成安装 进行 数据迁移 与 数据填充 还有 上传附件所需要的数据表
     * @return mixed HTML 视图页面
     */
    public function finish(){
        \Cli::call('hd migrate');
        \Cli::call('hd seed:make');
        $sql = <<<EOF
DROP TABLE IF EXISTS `attachment`;

CREATE TABLE `attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '会员编号',
  `name` varchar(80) NOT NULL,
  `filename` varchar(300) NOT NULL COMMENT '文件名',
  `path` varchar(300) NOT NULL COMMENT '文件路径',
  `extension` varchar(10) NOT NULL DEFAULT '' COMMENT '文件类型',
  `createtime` int(10) NOT NULL COMMENT '上传时间',
  `size` mediumint(9) NOT NULL COMMENT '文件大小',
  `data` varchar(100) NOT NULL DEFAULT '' COMMENT '辅助信息',
  `status` tinyint(1) unsigned NOT NULL COMMENT '状态',
  `content` text NOT NULL COMMENT '扩展数据内容',
  PRIMARY KEY (`id`),
  KEY `data` (`data`),
  KEY `extension` (`extension`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='附件';
EOF;
        Schema::sql($sql);
        fopen('./lock.php','w');
        return View::make();
    }
}