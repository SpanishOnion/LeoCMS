<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>LeoCMS开源免费内容管理系统</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <link href="./resource/hdjs/css/bootstrap.min.css" rel="stylesheet">
        <link href="./favicon.ico" rel="shortcut icon">
    </head>
    <body>
        <form class="form-horizontal" id="form">
            <div class="container">
                <div class="row">
                    <nav class="navbar navbar-default" role="navigation">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <span class="navbar-brand">LeoCMS开源免费内容管理系统</span>
                        </div>
                    </nav>
                    <ul class="list-group col-sm-3">
                        <li class="list-group-item ">版权信息</li>
                        <li class="list-group-item ">环境监测</li>
                        <li class="list-group-item active">初始数据</li>
                        <li class="list-group-item">安装完成</li>
                    </ul>
                    <div class="panel panel-default col-sm-9" style="padding:0px">
                        <div class="panel-heading">
                            <h3 class="panel-title">初始数据</h3>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <label for="" class="col-sm-2 control-label">主机地址</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="host" value="127.0.0.1">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="" class="col-sm-2 control-label">数据库用户名</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="user" value="root">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="" class="col-sm-2 control-label">数据库密码</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="password" value="">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="" class="col-sm-2 control-label">数据库名称</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="database" value="" placeholder="leocms">
                                </div>
                            </div>
                        </div>

                    </div>
                    <div style="float: right">
                        <a class="btn btn-primary" href="index.php?s=system/Install/environmental">上一步</a>
                        <button type="button" id="btn" class="btn btn-success">下一步</button>
                    </div>
                </div>
            </div>
        </form>
        <script src="./resource/js/common/helper.js"></script>
        <script>
            var DB = true, BT = I('btn');
            BT.onclick = function () {
                BT.innerText = '正在检测...';
                if (DB) {
                    DB = false;
                    ajax({
                        url : 'index.php?s=system/Install/cnDb',
                        data : {host : N('host').value, user : N('user').value, password : N('password').value, database : N('database').value},
                        success : function(e) {
                            !e ? location.href = 'index.php?s=system/install/finish' : modal(e);
                            BT.innerText = '下一步';
                            DB = true;
                        }
                    })
                }
            }
        </script>
    </body>
</html>