<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>LeoCMS开源免费内容管理系统</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link href="./resource/hdjs/css/bootstrap.min.css" rel="stylesheet">
    <link href="./resource/hdjs/css/font-awesome.min.css" rel="stylesheet">
    <link href="./favicon.ico" rel="shortcut icon">
</head>
<body>
<div class="container">
    <div class="row">
        <nav class="navbar navbar-default" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <span class="navbar-brand">LeoCMS开源免费内容管理系统</span>
            </div>
        </nav>
        <ul class="list-group col-sm-3">
            <li class="list-group-item active">版权信息</li>
            <li class="list-group-item">环境监测</li>
            <li class="list-group-item">初始数据</li>
            <li class="list-group-item">安装完成</li>
        </ul>
        <div class="panel panel-default col-sm-9" style="padding:0px">
            <div class="panel-heading">
                <h3 class="panel-title">版权声明CopyRight</h3>
            </div>
            <div class="panel-body">
                LeoCMS管理系统（lcgod.com）一贯高度重视知识产权保护并遵守中国各项知识产权法律、法规和具有约束力的规范性文件。重视正版，打击盗版。根据法律、法规和规范性文件要求，LeoCMS管理系统（lcgod.com）旨在保护权利人的合法权益的措施和步骤，当权利人发现在系统之家（lcgod.com）生成的链接所指向的第三方网页的内容侵犯其合法权益时，权利人应事先向LeoCMS（lcgod.com）发出"权利通知"，LeoCMS（lcgod.com）将根据中国法律法规和政府规范性文件采取措施移除相关内容或相关链接。
                <br>
                具体措施和步骤如下：
                <br>
                权利通知
                <br>
                任何个人或单位如果同时符合以下两个条件：
                <br>
                权利人发现LeoCMS管理系统（lcgod.com）侵害其合法权益；
                <br>
                权利人发现LeoCMS管理系统（lcgod.com）上有提供权利作品的相关连接;
                <br>
                请上述个人或单位务必以书面的通讯方式向LeoCMS管理系统（lcgod.com）提交权利通知。
                <br>
                注意：如果权利通知的陈述失实，权利通知提交者将承担对由此造成的全部法律责任（包括但不限于赔偿各种费用及律师费）。
                <br>
                请使用以下格式（包括各条款的序号）：
                <br>
                权利人对涉嫌侵权内容拥有商标权、著作权和/或其他依法可以行使权利的权属证明；
                <br>
                请充分、明确地描述确信被侵犯了权利人合法权益的内容并请提供非法登载该作品的第三方网址。
                <br>
                请指明涉嫌侵权网页的哪些内容侵犯了第2项中列明的权利人的合法权益。
                <br>
                请提供权利人具体的联络信息，包括姓名、身份证或护照复印件（对自然人）、单位登记证明复印件（对单位）、通信地址、电话号码、传真和电子邮件。
                <br>
                请提供涉嫌侵权内容在信息网络上的位置（如指明您举报的含有侵权内容的出处，即：指网页地址或网页内的位置）以便我们与您举报的含有侵权内容的网页的所有权人/管理人联系。
                <br>
                请在权利通知中加入如下关于通知内容真实性的声明：
                <br>
                （1）我本人为所投诉内容的合法权利人；
                <br>
                （2）在我举报的第三方网页上登载的内容侵犯了本人相应的合法权益。
                <br>
                （3）本人确认：如果本权利通知内容不完全属实，本人将承担由此产生的一切法律责任。
                <br>
                请在权利通知中加入以下陈述："我保证，本通知中所述信息是充分、真实、准确的，我是所投诉内容的合法权利人，或，我已获授权，有权行使第2项中列明内容的权益。"
                <br>
                请您签署该文件，如果您是依法成立的机构或组织，请您加盖公章。
                <br>
                本站点上的所有软件和资料均为软件作者提供和网友推荐收集整理而来，仅供学习和研究使用。如有侵犯你版权的，请来信775126470@qq.com指出，本站将立即改正。LeoCMS管理系统（lcgod.com）下载站对互联网版权绝对支持，净化网络版权环境。
                <br>
                访问本站的用户必须明白，LeoCMS管理系统（lcgod.com）软件对提供下载的软件等不拥有任何权利，其版权归该下载资源的合法拥有者所有。
                <br>
                本站保证站内提供的所有可下载资源（软件等等）都是由用户分享并上传按"原样"提供，本站未做过任何改动；但本网站不保证本站提供的下载资源的准确性、安全性和完整性；同时本网站也不承担用户因使用这些下载资源对自己和他人造成任何形式的损失或伤害。
                <br>
                未经本站的明确许可，任何人不得大量链接本站下载资源；不得复制或仿造本网站。本网站对其自行开发的或和他人共同开发的所有内容、技术手段和服务拥有全部知识产权，任何人不得侵害或破坏，也不得擅自使用。
                <br>
                如本站上的任何软件或资料侵犯你的版权，请与我们联系，本站对所有资源不负任何法律责任！
            </div>
        </div>
        <div style="float: right">
            <a class="btn btn-success" href="index.php?s=system/Install/environmental">下一步</a>
        </div>
    </div>
</div>
</body>