<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>LeoCMS开源免费内容管理系统</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <link href="./resource/hdjs/css/bootstrap.min.css" rel="stylesheet">
        <link href="./favicon.ico" rel="shortcut icon">
        <style>
            td{
                position:relative;
            }
            .icons{
                position: absolute;
                top: 0;left: 0;right: 0;bottom: 0;
                width: 20px;
                height: 20px;
                margin: auto;
                background-size: cover;
            }
            .icon-success{
                background-image: url(./resource/images/success.svg);
            }
            .icon-error{
                background-image: url(./resource/images/error.svg);
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <nav class="navbar navbar-default" role="navigation">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <span class="navbar-brand">LeoCMS开源免费内容管理系统</span>
                    </div>
                </nav>
                <ul class="list-group col-sm-3">
                    <li class="list-group-item ">版权信息</li>
                    <li class="list-group-item active">环境监测</li>
                    <li class="list-group-item">初始数据</li>
                    <li class="list-group-item">安装完成</li>
                </ul>
                <div class="panel panel-default col-sm-9" style="padding:0">
                    <div class="panel-heading">
                        <h3 class="panel-title">系统环境</h3>
                    </div>
                    <div class="panel-body">
                        <table class="table table-hover">
                            <tbody>
                            <tr>
                                <th>php版本</th>
                                <th><?php echo PHP_VERSION; ?></th>
                            </tr>
                            <tr>
                                <td>服务器环境</td>
                                <td><?php echo PHP_OS; ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="panel panel-default col-sm-9" style="padding:0">
                    <div class="panel-heading">
                        <h3 class="panel-title">环境检测</h3>
                    </div>
                    <div class="panel-body">
                        <table class="table table-hover">
                            <tbody>
                            <tr>
                                <td>php版本</td>
                                <td>
                                    <?php if (PHP_VERSION > 5.6) { ?>
                                        <i class="icons icon-success"></i>
                                    <?php } else { ?>
                                        <i class="icons icon-error errors"></i>
                                    <?php } ?>
                                </td>
                            </tr>
                            <tr>
                                <td>gd</td>
                                <td>
                                    <?php if (extension_loaded('gd')) { ?>
                                        <i class="icons icon-success"></i>
                                    <?php } else { ?>
                                        <i class="icons icon-error errors"></i>
                                    <?php } ?>
                                </td>
                            </tr>
                            <tr>
                                <td>curl</td>
                                <td>
                                    <?php if (extension_loaded('curl')) { ?>
                                        <i class="icons icon-success"></i>
                                    <?php } else { ?>
                                        <i class="icons icon-error errors"></i>
                                    <?php } ?>
                                </td>
                            </tr>
                            <tr>
                                <td>pdo</td>
                                <td>
                                    <?php if (extension_loaded('pdo')) { ?>
                                        <i class="icons icon-success"></i>
                                    <?php } else { ?>
                                        <i class="icons icon-error errors"></i>
                                    <?php } ?>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>

                </div>
                <div style="float: right">
                    <a class="btn btn-primary" href="index.php?s=system/install/copyright">上一步</a>
                    <button type="button" onclick="check();" class="btn btn-success">下一步</button>
                </div>
            </div>
        </div>
        <script>
            var err = !!document.getElementsByClassName('errors').length;
            function check() {
                err ? alert('请配置好当前服务器环境后安装') : location.href = 'index.php?s=system/install/database';
            }
        </script>
    </body>
</html>