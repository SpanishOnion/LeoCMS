<extend file='ROOT_PATH/resource/view/admin/wechat-master'/>
<block name="content">
    <div class="form-list container form-list-main">
        <form action="" style="display: block;">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">Token</label>
                        <div class="col-sm-9">
                            <input class="form-control" name="token" type="text" value="<?php echo v('token'); ?>" placeholder="请填写Token">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">EncodingAESKey</label>
                        <div class="col-sm-9">
                            <input class="form-control" name="encodingaeskey" type="text" value="<?php echo v('encodingaeskey'); ?>" placeholder="请填写encodingaeskey">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">AppID</label>
                        <div class="col-sm-9">
                            <input class="form-control" name="appid" type="text" value="<?php echo v('appid'); ?>" placeholder="请填写AppID">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">AppSecret</label>
                        <div class="col-sm-9">
                            <input class="form-control" name="appsecret" type="text" value="<?php echo v('appsecret'); ?>" placeholder="请填写AppSecret">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for=""  class="col-sm-2 control-label"></label>
                        <button class="btn btn-info funBtn subBtn" id="submit" type="button" style="margin-left:15px">立刻保存</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</block>