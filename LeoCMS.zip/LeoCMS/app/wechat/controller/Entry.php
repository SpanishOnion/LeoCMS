<?php namespace app\wechat\controller;

use houdunwang\route\Controller;

class Entry extends Controller{
    //动作
    public function index(){
        //此处书写代码...
    }
}
