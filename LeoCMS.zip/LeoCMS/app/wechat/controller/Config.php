<?php namespace app\wechat\controller;

use app\common\controller\AdminBase;
use system\model\Wechat_config;

class Config extends AdminBase
{
    public function __construct()
    {
        parent::__construct();
        Middleware::set('wcCfg');
    }

    public function index()
    {
        return View::make();
    }

    public function svCf()
    {
        if(IS_POST) {
            Wechat_config::findOrCreate(1)->save(['config' => json_encode($_POST)]);
            echo 1;
        }
    }
}