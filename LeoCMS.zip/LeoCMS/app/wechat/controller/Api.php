<?php namespace app\wechat\controller;

use houdunwang\route\Controller;
use houdunwang\wechat\WeChat;

class Api extends Controller
{
    public function __construct()
    {
        Middleware::set('wcCfg');
        WeChat::valid();
    }

    public function handler(){
        WeChat::instance('message')->text('收到消息了');
    }
}