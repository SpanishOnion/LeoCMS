var DBI = true, TB = I('tb'), ME = I('menus');
/**
 * 事件委托：设计模块按钮, 安装模块按钮, 卸载模块按钮, 彻底删除模块按钮
 */
document.body.addEventListener('click', function(e) {
    e = e || window.event;
    var t = e.target || e.srcElement, p = t.parentNode.previousElementSibling, id = t.parentNode.parentNode.getAttribute('data-id');
    if(DBI) {
        if (t.id === 'design') {
            togMod(t, '返回模块列表', '设计功能模块');
        } else if (has(t, 'ist-btn')) {
            DBI = false;
            t.innerText = '正在安装...';
            ajax({
                url : 'index.php?s=module/Module/togIst',
                data : {id : id, ac : 1},
                success : function (e) {
                    if (!e) {
                        modal('模块安装成功!');
                        ME.insertAdjacentHTML('beforeend', '<div id="vn' + id + '"><details><summary><span>' + p.innerText + '</span></summary></details><ul class="menus"><li><a href="index.php?a=' + p.previousElementSibling.innerText + '/Entry/index"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-tupian"></use></svg> 首页</a></li></ul></div>');
                        t.outerHTML = '<button class="btn btn-danger btn-xs uni-btn">卸载此模块</button>';
                        DBI = true;
                    }
                }
            })
        } else if (has(t, 'uni-btn')) {
            DBI = false;
            t.innerText = '正在卸载...';
            ajax({
                url : 'index.php?s=module/Module/togIst',
                data : {id : id, ac : 0},
                success : function (e) {
                    if (!e) {
                        modal('模块卸载成功!');
                        t.outerHTML = '<button class="btn btn-success btn-xs ist-btn">安装此模块</button>';
                        I('vn' + id).outerHTML = '';
                        DBI = true;
                    }
                }
            })
        } else if (has(t, 'del-btn')) {
            modal('彻底删除模块后, 无法再进行恢复, 确认要删除吗？', function () {
                DBI = false;
                t.innerText = '正在删除...';
                ajax({
                    url : 'index.php?s=module/Module/del',
                    data : {id : id, itf: t.parentNode.previousElementSibling.previousElementSibling.innerText},
                    success : function (e) {
                        if (e === '1') {
                            modal('模块已被彻底删除!');
                            t.parentNode.parentNode.outerHTML = '';
                            I('vn' + id).outerHTML = '';
                            DBI = true;
                        }
                    }
                })
            });
        }
    }
});

/**
 * 保存模块按钮点击事件
 */
I('btn-sub').onclick = function () {
    var o = getPost();
    if (!!o) {
        var dgs = I('digest');
        o.digest = dgs.value;
        ajax({
            url : 'index.php?s=module/Module/design',
            data : o,
            success : function (e) {
                if (!e) {
                    modal('模块标识已存在，请重新输入');
                } else {
                    modal('模块创建成功！');
                    TB.insertAdjacentHTML('beforeend', '<tr data-id="' + e + '"><td>' + (~~TB.lastElementChild.firstElementChild.innerText + 1) + '</td><td>' + o.itf + '</td><td>' + o.name + '</td><td><button class="btn btn-success btn-xs ist-btn">安装此模块</button> <button class="btn btn-off btn-xs del-btn">彻底删除此模块</button></td></tr>');
                    togMod(I('design'), '返回模块列表', '设计功能模块');
                    resetForm();
                    dgs.value = '';
                }
            }
        })
    }
};