document.body.addEventListener('click', function(e) {
    e = e || window.event;
    var t = e.target || e.srcElement;
    if (t.id === 'kw-add') {
        togMod(t, '返回关键词列表', '添加关键词');
    } else if (has(t, 'ist-btn') && DBI) {
        DBI = false;
        t.innerText = '正在安装...';
        ajax({
            url : 'index.php?s=module/Module/togIst',
            data : {id : t.parentNode.parentNode.getAttribute('data-id'), ac : 1},
            success : function (e) {
                if(e === '1') {
                    modal('模块安装成功!');
                    t.outerHTML = '<button class="btn btn-danger btn-xs uni-btn">卸载此模块</button>';
                    DBI = true;
                }
            }
        })
    } else if (has(t, 'edt-btn')) {
        console.log(t.parentNode.parentNode.getAttribute('data-id'));
        //modal
    } else if (has(t, 'del-btn')) {
        modal('彻底删除模块后, 无法再进行恢复, 确认要删除吗？', function () {
            DBI = false;
            t.innerText = '正在删除...';
            ajax({
                url : 'index.php?s=module/Module/del',
                data : {id : t.parentNode.parentNode.getAttribute('data-id'), itf: t.parentNode.previousElementSibling.previousElementSibling.innerText},
                success : function (e) {
                    if (e === '1') {
                        modal('模块已被彻底删除!');
                        t.parentNode.parentNode.outerHTML = '';
                        DBI = true;
                    }
                }
            })
        });
    }
});

var tb = I('tb');
I('btn-sub').onclick = function () {
    var na = I('name').value, co = I('content').value, k = ~~tb.lastElementChild.firstElementChild.innerText + 1;
    ajax({
        url : 'index.php?a=base/Keyword/saveKw',
        data : {name : na, content : co},
        success : function (res) {
            if (!!res) {
                tb.insertAdjacentHTML('beforeend','<tr data-id="' + res.id + '"><td>' + k  + '</td><td>' + na + '</td><td>' + co + '</td><td><button class="btn btn-success btn-xs ist-btn">编辑该关键词</button> <button class="btn btn-off btn-xs del-btn">删除该关键词</button></td></tr>');
                modal('添加关键词成功!');
                togMod(I('kw-add'), '返回关键词列表', '添加关键词');
            }
        }
    })
};
