// 点击事件
I('submit').onclick = function () {
    var data = getPost();
    if(!!data) ajax({
        url : 'index.php?s=wechat/Config/svCf',
        data : data,
        success : function () { modal('保存成功') }
    });
};