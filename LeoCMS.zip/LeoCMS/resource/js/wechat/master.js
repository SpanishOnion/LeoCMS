var IPT = T('input', true), AF = I('form'), TS = true;
function getPost(f) {
    var data = f ? T('input', true, f) : IPT, l = data.length, o = {};
    while(l--) {
        if(data[l].type !== 'checkbox' && !data[l].value){
            modal(data[l].getAttribute('placeholder'));
            return false;
        }
        o[data[l].getAttribute('name')] = data[l].value;
    }
    return o;
}

function resetForm() {
    var l = IPT.length;
    while(l--) {
        if(IPT[l].type === 'checkbox'){
            IPT[l].checked = false
        } else {
            IPT[l].value = '';
        }
    }
}

//通用事件
document.body.onclick = function(e) {
    e = e || window.event;
    var t = e.target || e.srcElement;
    if(has(t, 'btn-signOut')) {    //退出按钮
        modal('确定要退出吗？', function () { location.href = 'index.php?s=admin/Admin/signOut'; } )
    } else if(has(t, 'btn-switch')) {    //切换账号按钮
        modal('确定要切换账号吗？', function () { location.href = 'index.php?s=admin/Admin/login'; } )
    } else if(has(t, 'mask')) {    //遮罩层
        fadeOut(t.parentNode);
    } else if(has(t, 'btn-cancel')) {    //取消按钮
        while(true) {
            t = t.parentNode;
            if(t.parentNode.nodeName === 'BODY'){
                fadeOut(t);
                break;
            }
        }
    }
};

/**
 * 列表页与编辑页的toggle切换
 * @param t Element 当前target
 * @param str1    表单隐藏时 按钮的名称
 * @param str2    表单显示时 按钮的名称
 */
function togMod(t, str1, str2) {
    if(TS){
        t.outerHTML = '<button class="btn btn-success btn-return" id="'+ t.id +'">' + str1 + '</button>';
        AF.previousElementSibling.style.display = 'none';
        AF.style.display = 'block';
    } else {
        t.outerHTML = '<button class="btn btn-info btn-addAtc" id="'+ t.id +'">' + str2 + '</button>';
        AF.style.display = 'none';
        AF.previousElementSibling.style.display = 'block';
    }
    TS = !TS;
}