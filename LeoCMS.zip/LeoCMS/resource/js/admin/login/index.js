// AJAX登录
var usr = N('username'), psd = N('password'), cod = N('code'), u, p, c;

//按钮提交
C('submit').onclick = login;

//键盘提交
document.onkeydown = function (e) {
    if(e.which === 13) login();
};

//提交方法
function login() {
    u = usr.value;
    p = psd.value;
    c = cod.value;
    if(!u) {
        modal('请输入管理员账号');
    } else if (!p) {
        modal('请输入管理员密码');
    } else if (!c) {
        modal('请输入验证码');
    } else {
        ajax({
            url : 'index.php?s=admin/Admin/check',
            data : {username : u, password : p, code : c},
            success: function(e) {
                if(!!e) {
                    switch(e) {
                        case '0' :
                            modal('您输入的验证码有误，请重新输入！');
                            break;
                        case '1' :
                            modal('您输入的管理员账号不存在，，请重新输入！');
                            break;
                        case '2' :
                            modal('您输入的密码有误，请重新输入！');
                            break;
                        default:
                            window.location.href = 'index.php?s=admin/Entry/index';
                    }
                }
            }
        })
    }
}

//切换验证码
C('code').onclick = function () {
    this.src += '&';
};