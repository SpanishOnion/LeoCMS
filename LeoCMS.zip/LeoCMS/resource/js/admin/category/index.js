//配置信息
var _c = {
    delBtn : '删除该分类',
    delMsg : '确认要删除此分类吗？',
    delUrl : 'index.php?s=admin/Category/del',
    addUrl : 'index.php?s=admin/Category/edit',
    addMsg : '成功添加顶级分类！',
    btn : [
        {c : 'success', a : 'adSon', m : '添加子类', f : adSon},
        {c : 'primary', a : 'edIfo', m : '修改分类信息', f : edIfo}
    ]
},
    sonModal = C('sonModal'),
    pCate = C('par-cate', false, sonModal),
    edMdl = C('edtModal');

//自定义方法
function adSon() {
    //更换option内容
    tbody = t.parentNode;
    pCate.innerText = tbody.previousElementSibling.previousElementSibling.innerText;
    //设置option值 此时tbody变量设置为tr元素，所以修改后是追加至tr元素后
    tbody = tbody.parentNode;
    pCate.value = tbody.getAttribute('data-id');
    //重置表单
    modalForm = sonModal;
    modalInput = C('form-control', true, modalForm);
    resetInput();
    //显示表单
    fadeIn(sonModal);
    //addNum设为空，即为添加动作
    addNum = '';
    //将自定义方法复制给f,供edit()方法使用
    f = [conCate, '成功添加子类！'];
}

//自定义拼接HTML内容
function conCate(res) {
    i = tbody.getAttribute('data-id');
    //此时的tbody为选中的父类tr标签, 在后面会将tbody替换为最后一位子类tr元素 不存在子类则不替换
    tr = '<tr data-id="' + res.id + '" data-pid="' + i + '"><td>' + tbody.firstElementChild.innerText + '</td>';
    //递归判断子类
    //判断是否是当前tr元素时的pid是否为0 为0则是给顶级分类添加子类 所以赋值└─符号
    if(tbody.getAttribute('data-pid') === '0') {
        str = '└─';
    } else {
        //不是顶级分类 则获取|符号出现的数量
        k = pCate.innerText.match(/│/g);
        //不是顶级分类且没有|符号,说明是二级分类
        if(!k) {
            str = '│&nbsp;&nbsp;&nbsp;&nbsp;└─';
        } else {
            //不是顶级分类也不是二级分类 则递归增加|符号
            str = '';
            //如果父类有一个|符号,那么子类需要2个,而while是递减,所以需要长度+1
            l = k.length + 1;
            //拼接树形符号
            while(l--) {
                str += '│&nbsp;&nbsp;&nbsp;&nbsp;';
            }
            //拼接完|符号后追加上结束符
            str += '└─';
        }
    }
    //此时赋值tr元素内容, 之后在edit()方法中即可进行追加tr
    tr += '<td>' + str + modalInput[0].value + '</td><td>' + modalInput[2].value + '</td>';
    //递归赋值tbody 在edit()方法中即可追加至最后一位子类后方
    //若存在子类,则从最后一位tr元素开始向上查找,直到找到最后一位子元素,则停止查找
    if(!!tbody.nextElementSibling && tbody.nextElementSibling.getAttribute('data-pid') === i) {
        //赋值给最后一位tr元素
        tbody = tbody.parentNode.lastElementChild;
        //递归向上查询
        while(tbody.getAttribute('data-pid') !== i) {
            tbody = tbody.previousElementSibling;
        }
    }
}

function edIfo() {
    fadeIn(edMdl);
    addNum = t.parentNode.parentNode.getAttribute('data-id');
    //重置表单
    modalForm = edMdl;
    resetInput();
    ajax({
        url : 'index.php?s=admin/Category/getCate',
        data : {'id' : addNum},
        success : function (e) {
            e = JSON.parse(e);
            i = 0;
            l = e.length;
            a = [];
            for(; i < l; i++) {
                a.push('<option class="par-cate" value="'+ e[i].id +'">'+ e[i]._name +'</option>')
            }
            a.unshift('<option class="par-cate" value="0">顶级分类</option>');
            modalInput[1].innerHTML = a.join('');
            f = [conCate, '修改分类成功！'];
            a = null;
        }
    })
}

function reLod() {
    console.log(123);
}