//预定义全局变量
//i索引键名，l长度，k关联键名，v键值，t元素，tr行元素，str空字符串，tbody表单元素，modalForm模态表单，modalInput表单input
//addNum:控制添加按钮的执行动作，默认为空是添加动作
//a数组，f方法
//s:控制当前配置文件序号 默认0号,即为_c
//o:储存ajax提交的数据对象
//db...AJAX连击阀
var a, f, i, k, l, v, o, t, tr, str, tbody, modalForm, modalInput, addNum,
    s = 0, dbDel = true, dbEdit = true;
//委托页面中所有的点击事件
document.body.onclick = function(e) {
    e = e || window.event;
    t = e.target || e.srcElement;
    /*通用事件*/
    if(has(t, 'del') && dbDel) {    //删除按钮 AJAX删除
        tr = t.parentNode.parentNode;
        addNum = tr.getAttribute('data-id');
        modal(_c.delMsg, function() {
            dbDel = false;
            ajax({
                url : _c.delUrl,
                data : {id : addNum},
                success : function(res) {
                    if(res === '1'){
                        tr.parentNode.removeChild(tr);
                        modal('删除成功');
                    }else{
                        modal('删除失败');
                    }
                    dbDel = true;
                }
            });
        });
    } else if(has(t, 'btn-add')) {    //添加按钮--显示表单模态框--清空表单数据
        modalForm =  getPar(t, 'form-list').nextElementSibling;
        resetInput();
        fadeIn(modalForm);
        tbody = T('tbody', false, getPar(t, 'form-list'));    //获取当前tbody元素
        addNum = '';    //赋值addNum为空，使edit()方法变为添加动作
    } else if(has(t, 'btn-ajax-edit')) {    //立即添加按钮-- 调用AJAX编辑方法
        if(getPost()) return;
        edit();
    } else if(has(t, 'btn-signOut')) {    //退出按钮
        modal('确定要退出吗？', function(){ location.href = 'index.php?s=admin/Admin/signOut'; } )
    } else if(has(t, 'btn-switch')) {    //切换账号按钮
        modal('确定要切换账号吗？', function(){ location.href = 'index.php?s=admin/Admin/login'; } )
    } else if(has(t, 'mask')) {    //遮罩层
        fadeOut(t.parentNode);
        f = null;    //置空自定义方法
    } else if(has(t, 'btn-cancel')) {    //取消按钮
        while(1) {
            t = t.parentNode;
            if(t.parentNode.nodeName === 'BODY'){
                fadeOut(t);
                f = null;    //置空自定义方法
                break;
            }
        }
    } else if(typeof _c !== 'undefined') {    /*自定义事件*/
        a = _c.btn;
        l = a.length;
        while(l--) {
            if(has(t, a[l].a)) {
                return a[l].f();    //执行自定义事件并且停止循环
            }
        }
    }
};

//根据NodeList来赋值给 将要进行Ajax提交的data对象o
function getPost() {
    i = 0;
    l = modalInput.length;
    o = {};   //将表单的值赋给对象o，也可以考虑更改ajax方法 直接序列化成字符串传参
    for(; i < l; i++){
        v = modalInput[i].value;
        if(v === '' && modalInput[i].type !== 'hidden'){    //当表单内容为空时 提示信息 并return true
            modal('请填写' + (modalInput[i].previousElementSibling ? modalInput[i].previousElementSibling.innerText : '表单'));
            return true;
        }
        o[modalInput[i].name] = v;
    }
    o.id = addNum;    //获取主键ID 若为空则是添加动作
}

//重置表单
function resetInput() {
    modalInput = C('form-control', true, modalForm);
    i = 0;
    l = modalInput.length;
    for(; i < l; i++) {    //清空表单内容
        modalInput[i].value = modalInput[i].nodeName === 'SELECT' ? modalInput[i].firstElementChild.value : '';
    }
}

//公共方法 AJAX添加&编辑
function edit() {
    if(dbEdit){    //防止用户连击
        dbEdit = false;    //关闭连击阀
        ajax({
            url : _c.addUrl,
            data : o,    //o.id为空时进行添加 不为空则根据id进行编辑
            success : function(res) {
                if(res !== '0') {    //res返回值不为0时 表示数据库操作成功
                    //转为JSON后，字符串0会变成数字0
                    res = JSON.parse(res);
                    i = 0;
                    if(res.type === 0) {    //type为0则是添加动作 反之则是修改动作
                        //tr = document.createElement('TR');
                        //拼接HTML标签
                        if(!!f && typeof f[0] === 'function') {    //判断自定义拼接HTML方法是否存在，若存在则自定义拼接
                            f[0](res);
                            coInMo('afterend', f[1]);
                            //此时tbody为替换后的元素, 所有如果tbody的pid与追加的元素相同  则表示是同级分类 改变└─符号为├─
                            if(tbody.getAttribute('data-pid') === tbody.nextElementSibling.getAttribute('data-pid')) {
                                tbody = tbody.firstElementChild.nextElementSibling;
                                tbody.innerText = tbody.innerText.replace('└─','├─');
                            }
                            f = null;
                        } else {
                            tr = '<tr data-id="' + res.id + '"><td>' + res.id + '</td>';
                            for(; i < l; i++) {
                                v = modalInput[i];
                                if(!has(v, 'skip')) {    //class含有skip时跳过
                                    if(has(v, 'addTime')) {    //class含有addTime时拼接指定字符串
                                        tr += '<td>从未登录</td>';
                                    } else {
                                        //判断是否为下拉框
                                        tr += (v.nodeName === 'SELECT') ? '<td>' + v.options[v.selectedIndex].innerText + '</td>' : '<td>' + v.value + '</td>';
                                    }
                                }
                            }
                            coInMo('beforeend', _c.addMsg);    //调用coInMo方法进行拼接按钮 并将拼接好的tr元素追加至页面 并提示消息
                        }
                    } else {    //type不为0则是修改动作
                        if(!!f && typeof f[0] === 'function') {    //存在自定义动作 则执行自定义动作
                            f[0](res);
                            modal(f[1]);
                        } else {
                            for(; i < l; i++) {    //编辑成功后 根据表单的内容来修改页面内容
                                v = modalInput[i];
                                //判断是否为下拉框
                                tr.children[i + 1].innerText = v.nodeName === 'SELECT' ? v.options[v.selectedIndex].innerText : v.value;
                            }
                            modal(_c.edtMsg);
                        }
                    }
                    if(!!modalForm) fadeOut(modalForm);    //执行完添加或编辑动作后 隐藏表单模态框
                }
                dbEdit = true;    //打开连击阀
            }
        })
    }
}

/**
 * coInMo 拼接按钮--追加至页面--提示消息
 * @param p string 追加方式
 * @param m string 提示信息
 */
function coInMo(p, m) {
    i = 0;
    a = _c.btn;    //获取列表页的按钮配置信息
    l = a.length;
    tr += '<td>';    //td开始标签
    for(; i < l; i++) {    //根据配置的button信息拼接按钮
        tr += '<button class="btn btn-' + a[i].c + ' btn-xs ' + a[i].a + '">' + a[i].m + '</button> ';
    }
    if(!!_c.delBtn) tr += '<button class="btn btn-danger btn-xs del">'+ _c.delBtn +'</button></td></tr> ';    //配置过del按钮则进行追加
    tbody.insertAdjacentHTML(p, tr);    //追加方式
    modal(m);    //提示信息
}