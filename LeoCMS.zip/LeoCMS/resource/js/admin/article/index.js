//初始化配置信息
var _c = {
    delMsg : '确认要彻底删除此篇文章吗？删除后将无法再恢复',
    delUrl : 'index.php?s=admin/Article/del',
    addUrl : 'index.php?s=admin/Article/edit',
    addMsg : '成功添加文章！',
    btn : [
        {c : 'success', a : 'edAtc', m : '编辑此篇文章', f : edAtc},
        {c : 'danger', a : 'delRec', m : '删除至回收站', f : delRec}
    ]
},
af = document.forms[0], thb = C('img-thumbnail'), fb;

/**
 * 初始化KindEditor
 */
KindEditor.ready(function (K) {
    window.editor = K.create('#editor_id', {
        cssPath : './resource/js/admin/SyntaxHighlighter/styles/shCoreDefault.css',
        uploadJson : './resource/js/admin/KindEditor/php/uploadJson.php',
        fileManagerJson : './resource/js/admin/KindEditor/php/file_manager_json.php',
        allowFileManager : true,
        filterMode : false
    });
    fb = C('ke-edit-iframe').contentWindow.document.body;    //获取生成的iFrame标签中的body元素
});

/**
 * 为body增加委托点击事件
 */
document.body.addEventListener('click',function () {
    if(has(t, 'btn-addAtc')) {    //添加文章 按钮
        resetInput();    //清空普通input内容
        fb.innerHTML = '';    //清空编辑器
        thb.src = './resource/images/default.jpg';    //恢复默认图片
        hideList();    //隐藏列表页 显示编辑页
        addNum = '';
        f = [addAtc, '成功添加文章！'];    //将自定义方法赋值在f数组中,供edit()在请求完成后进行调用
    } else if(has(t, 'btn-return')) {    //返回列表 按钮
        showList();
    } else if(has(t, 'upImage')) {    //上传图片 按钮
        require(['util'], function (util) {
            options = {
                multiple: false,    //是否允许多图上传
                data:'',    //data为文件的附加数据值，开发者根据业务需要自行添加
                hash:1    //确定上传文件标识(可以是用户编号，标识为此用户上传的文件，系统使用这个字段值来显示文件列表)
            };
            util.image(function (images) {  //上传成功的图片，数组类型 
                images = images[0];
                if(!!images) {
                    thb.src = images;
                    thb.parentNode.previousElementSibling.firstElementChild.value = images;
                }
            }, options)
        });
    } else if(has(t, 'rm-img')) {    //删除图片 按钮
        t.previousElementSibling.src = './resource/images/default.jpg';
        t.parentNode.previousElementSibling.firstElementChild.value = '';
    } else if(has(t, 'subBtn')) {    //立即发布 按钮
        if(getPost()) return;    //获取post数据 若有未填写的内容则终止操作
        var s = fb.getElementsByTagName('script'),
            k = C('ke-script', true, fb),
            h = C('hidden');
        rmCd(fb, s);
        if(k[0]){ rmCd(fb, k); }
        h.value = fb.innerHTML;
        o.content = h.value;
        f = addNum === '' ? [addAtc, '成功添加文章！'] : [edtAtc, '成功修改文章！'];    //将自定义方法赋值在f数组中,供edit()在请求完成后进行调用
        edit();
    } else if(has(t, 'rdcRcc')) {
        modal('确认要还原该文章吗？', rdcRcc);
        tr = t.parentNode.parentNode;
    } else if(has(t, 'btn-clear')) {
        v = t;
        modal('确认要清空回收站吗？清空后所有文章数据都将无法恢复！', clrRcc)
    }
});

/**
 * rmCd 过滤KindEditor编辑器中多余的HTML标签
 * @param p  祖先元素 (依赖祖先元素删除子元素)
 * @param c  要删除的元素集合
 */
function rmCd(p, c){
    i = 0;
    while(c[i]){
        p.removeChild(c[i]);
    }
}

/**
 * 隐藏列表页 显示编辑页
 */
function hideList() {
    C('btn-atc').outerHTML = '<button class="btn btn-success btn-return btn-atc">返回列表</button>';
    af.previousElementSibling.style.display = 'none';
    af.style.display = 'block';
}

/**
 * 显示列表页 隐藏编辑页
 */
function showList() {
    af.style.display = 'none';
    af.previousElementSibling.style.display = 'block';
    C('btn-atc').outerHTML = '<button class="btn btn-info btn-addAtc btn-atc">添加文章</button>';
}
/**
 * 异步添加后后调用的自定义处理方法
 * @param res    AJAX返回的response结果
 */
function addAtc(res) {
    tbody = T('tbody').lastElementChild;
    tr = '<tr data-id="' + res.id + '"><td>' + res.id + '</td><td>' + o.title + '</td><td>' + o.author + '</td><td>' + res.name + '</td><td>暂未修改</td><td>' + res.time + '</td><td>0</td>';
    showList();
}

/**
 * 编辑按钮点击后 调用此方法获取文章数据并赋值到页面
 */
function edAtc() {
    hideList();
    modalInput = modalInput = C('form-control', true);
    tr = t.parentNode.parentNode;    //获取将要修改的tr元素
    addNum = tr.getAttribute('data-id');    //获取将要修改的文章的主键id
    ajax({
        url : 'index.php?s=admin/Article/get',
        data : {id : addNum},
        success : function (res) {
            res = JSON.parse(res);
            for(k in res) {
                N(k).value = res[k];
            }
            thb.src = res.thumb;
            fb.innerHTML = res.content;
        }
    })
}

/**
 * 异步编辑后调用的自定义处理方法
 * @param res
 */
function edtAtc(res) {
    str = tr.lastElementChild.previousElementSibling.previousElementSibling;
    tr.outerHTML = '<tr data-id="' + o.id + '"><td>' + tr.firstElementChild.innerText + '</td><td>' + o.title + '</td><td>' + o.author + '</td><td>' + str.previousElementSibling.previousElementSibling.innerText + '</td><td>'+ res.time +'</td><td>' + str.innerText + '</td><td>0</td><td><button class="btn btn-success btn-xs edAtc">编辑此篇文章</button> <button class="btn btn-danger btn-xs delRec">删除至回收站</button></td>';
    showList();
}

/**
 * 提示是否删除至回收站
 */
function delRec() {
    tr = t.parentNode.parentNode;
    modal('确认要将此篇文章删除至回收站吗? 删除后可在回收站进行恢复', recycle);
}

/**
 * 删除至回收站
 */
function recycle() {
    ajax({
        data : {id : tr.getAttribute('data-id')},
        url : 'index.php?s=admin/Article/toRcc',
        success : function(res) {
            if(res === '1') {
                modal('删除成功！');
                fadeOut(tr);
                setTimeout(tr.parentNode.removeChild(tr), 2000)
            }
        }
    })
}

/**
 * 还原文章
 */
function rdcRcc() {
    ajax({
        data : {id : tr.getAttribute('data-id')},
        url : 'index.php?s=admin/Article/rdcRcc',
        success : function(res) {
            if(res === '1') {
                modal('还原成功！请返回列表页查看');
                fadeOut(tr);
                setTimeout(tr.parentNode.removeChild(tr), 2000)
            }
        }
    })
}

/**
 * 清空回收站
 */
function clrRcc() {
    if(dbDel) {
        dbDel = false;
        a = [];
        tbody = T('tbody');
        tr = tbody.firstElementChild;
        str = tr.nextElementSibling;
        while(!!str) {    //递归push赋值
            a.push(str.getAttribute('data-id'));
            str = str.nextElementSibling;
        }
        ajax({
            url : 'index.php?s=admin/Article/del',
            data : {id : a},    //此时a为JS数组  在AJAX方法中会转换为以逗号分隔的字符串 [id : 1,2,3]
            success : function(res) {
                if(res === '1') {    //PHP返回数值1 会转换为字符串给JS 所以此处这样判断是否操作成功
                    modal('成功清空回收站');
                    v.className = 'btn btn-default';    //更换为default按钮
                    tbody.innerHTML= tr.outerHTML;    //清空tbody元素内容
                    dbDel = true;    //打开连击阀
                    tbody = null;    //释放变量
                    tr = null;
                    a = null;
                    str = null;
                }
            }
        })
    }
}