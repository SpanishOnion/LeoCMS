I('backup').onclick = backup;
I('tbd').onclick = function (e) {
    e = e || window.event;
    var t = e.target || e.srcElement;
    if (has(t, 'rdc')) {
        var path = t.parentNode.previousElementSibling.previousElementSibling.firstElementChild.innerText;
        (function rdc(){
            ajax({
                url : 'index.php?s=admin/Entry/recovery',
                data : {path : path},
                success : function (e) {
                    if (!!e) {
                        e = JSON.parse(e);
                        modal(e.msg);
                        if (!!e.s) setTimeout(rdc, 100);
                    }
                }
            })
        })()
    }
};

function backup() {
    ajax({
        url : 'index.php?s=admin/Entry/backup',
        success : function (e) {
            if (!!e) {
                e = JSON.parse(e);
                modal(e.msg);
                if (!!e.s) setTimeout(backup, 100);
            }
        }
    })
}