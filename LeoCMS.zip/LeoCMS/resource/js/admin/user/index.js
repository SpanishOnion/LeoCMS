//配置信息
var _c = {
    delBtn : '删除该账号',
    delMsg : '确认要删除此账号吗？',
    delUrl : 'index.php?s=admin/User/del',
    addUrl : 'index.php?s=admin/User/edit',
    addMsg : '成功添加管理员账号！',
    btn : [
        {c : 'success', a : 'edPsw', m : '修改密码'},
        {c : 'primary', a : 'edNcn', m : '修改昵称'}
    ],
    func : {
        'nickName' : nickName
    }
};
//自定义方法
function nickName() {

}