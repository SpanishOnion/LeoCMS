//公共JS函数库
/* AJAX
* @param String obj.type [http请求方式, POST或GET]
* @param String obj.url [发送请求的url]
* @param Boolean obj.async [是否为异步请求, true为异步, false为同步]
* @param Object obj.data [AJAX发送的数据]
* @param Function obj.success [AJAX发送并接收成功后的回调函数]
*/
function ajax(obj) {
    obj = obj || {};
    obj.success = obj.success || function () {};
    var method = !!obj.method === false ? 'POST' : obj.method.toUpperCase(),
        url = obj.url || '',
        async = obj.async || true,
        data = obj.data || '',
        //创建xhrRequest对象 兼容用IE5或者IE6的睿智 (逃
        xhr = XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.xhr'),
        params = [],
        k;
    //对特殊字符串进行encodeURIComponent编码
    for (k in data){
        params.push(encodeURIComponent(k) + '=' + encodeURIComponent(data[k]));
    }
    var postData = params.join('&');
    //判断POST方式或GET方式提交
    if (method === 'POST') {
        xhr.open(method, url, async);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded;charset=utf-8');
        xhr.send(postData);
    } else if (method === 'GET') {
        xhr.open(method, url + '?' + postData, async);
        xhr.send(null);
    }
    //判断状态码是否是200
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            obj.success(xhr.responseText);
        }
    }
}

function run() {
    ajax({
        url : 'test.php',
        data : {some : 123, data:666},
        success:function(res){
            console.log(JSON.parse(res));
        }
    })
}

/**
 *
 * @param c string 需要搜索的className
 * @param s boolean 是否搜索多个元素，默认只搜索一个，true为搜索多个
 * @param f Element 祖先元素 是否需要根据祖先来查找class 默认不需要
 * @returns {*} 元素集合 默认单个元素
 * @constructor
 */
function C(c, s, f) {
    if (s) {
        return f ? f.getElementsByClassName(c) : document.getElementsByClassName(c);
    } else {
        return f ? f.getElementsByClassName(c)[0] : document.getElementsByClassName(c)[0];
    }
}

/**
 * fadeOut淡出
 * @param el Element 想要淡出的元素
 */
//储存正在进行fade动画的元素
var fadeEle;
function fadeOut(el) {
    el.style.opacity = 1;
    // fOSta = true;
    (function fade() {
        //如果透明度小于等于0 则让元素消失 不再继续递归动画 否则继续递归动画
        if ( ( (el.style.opacity -= .1) <= 0 ) ) {
            //如果不存在淡入动画，则可以让元素消失，否则进行任何操作
            if(fadeEle !== el){
                el.style.display = 'none';
            }
        } else {
            requestAnimationFrame(fade);
        }
    })();
}

/**
 * fadeIn淡入
 * @param el element 想要淡入的元素
 * @param display string 淡入元素display的类型
 */
function fadeIn(el, display) {
    //初始化透明度 与 display 并声明fadeIn动画已经开始
    el.style.opacity = 0;
    el.style.display = display || "block";
    fadeEle = el;
    (function fade() {
        //将字符串转换为浮点类型进行比较
        var val = parseFloat(el.style.opacity);
        //如果透明度小于1 则递归动画 否则声明fadeIn动画已进行完毕，不再继续递归动画
        if ( !( (val += .1) > 1 ) ) {
            el.style.opacity = val;
            requestAnimationFrame(fade);
        }else{
            fadeEle = null;
        }
    })();
}

/**
 * getPar 根据class获取父级元素
 * @param e 子元素
 * @param c 父级元素className
 * @returns {*} 父级元素
 */
function getPar(e, c) {
    while(1) {
        if( has(e, c) ) {
            return e;
        }
        e = e.parentNode;
    }
}

/**
 * JQ底层源码也是使用indexOf检测 因为简单匹配indexOf最快 而match适合复杂模式匹配 检测长度
 * @param e 需要检测的元素
 * @param c 需要检测的className
 * @returns {boolean} 是否包含该class
 */
function has(e, c) {
    return (' ' + e.className + ' ').indexOf(' ' + c + ' ') !== -1
}

/**
 * L 根据选择器查找元素
 * @param s  CSS选择器
 * @param b  是否选择NodeList集合 默认只选择第一个
 * @param f  是否根据父级元素来查找 默认不根据父级元素查找
 * @returns {*}
 * @constructor
 */
function L(s, b, f) {
    if(b){
        return f ? f.querySelectorAll(s) : document.getElementsByClassName(s);
    }else{
        return f ? f.querySelector(s) : document.querySelector(s);
    }
}

/**
 * modal模态框 此模态框渐入渐出效果依赖于fadeIn fadeOut方法
 * 可扩展 ：可以在CSS文件中可给button元素添加hover focus 实现点击效果 给#modalY元素添加Animation 实现fadeDown fadeUp效果
 * @param s string 想要提示的信息
 * @param f function 点击确认后运行的方法
 */
//储存定时器
var mdTime = null;
function modal(s, f) {
    var hasF = typeof f === 'function', modalS = I('modalS'), modalY = I('modalY'), buttons = '', mask= '', modal = I('modal');
    //如果有函数，并且不存在button，则拼接button
    if(hasF && !modalY) {
        buttons = '<button id="modalY" style="height: 28px;line-height: 28px;margin: 5px 5px 0;padding: 0 15px;border: 1px solid #1E9FFF;border-radius: 2px;cursor: pointer;background-color: #1E9FFF;">确认</button>' +
        '<button id="modalN" style="height: 28px;line-height: 28px;margin: 5px 5px 0;padding: 0 15px;border: 1px solid transparent;border-radius: 2px;cursor: pointer;color: #000;background-color: #eef;">取消</button>';
        mask = '<div id="modalM" style="width: 100%;height: 100%;position: fixed;top: 0;left: 0;background: rgba(0,0,0,.3)"></div>';
    }
    //若modal子元素不存在则创建并追加至页面中
    if(modalS === null) {
        var str = '<div id="modal" style="display: none;position:relative;z-index:2">';
        //如果有函数，则需要拼接遮罩层
        if(hasF){
            str += mask;
        }
        str += '<div id="modalS" style="padding: 10px 20px 20px;position: fixed;top: 20%;left: 50%;transform: translate(-50%,-50%);text-align: center;font-size: 14px;border-radius: 3px;background-color: rgba(0,0,0,.6);color: #fff;">' +
            '<div id="modalT" style="padding: 12px 25px;text-align: center;">' + s + '</div>';
        //如果有函数，则需要拼接按钮
        if(hasF){
            str += buttons;
        }
        str += '</div></div>';
        //将modal追加至body中
        document.body.insertAdjacentHTML('beforeend', str);
        //获取modal元素
        modal = I('modal');
    } else {
        //如果有函数，有modal，但是没有按钮，则需要追加按钮与遮罩层
        if(hasF && !modalY) {
            modalS.insertAdjacentHTML('beforebegin', mask);
            modalS.insertAdjacentHTML('beforeend', buttons);
            //如果没有函数，有modal,并且存在按钮,则移除按钮与遮罩层
        }else if(!hasF && modalY) {
            modal.removeChild(I('modalM'));
            modalS.removeChild(modalY);
            modalS.removeChild(I('modalN'));
        }
        //清除其他定时器，并且设置提示信息
        clearTimeout(mdTime);
        I('modalT').innerText = s;
    }
    //显示modal
    fadeIn(modal);
    //若传了函数，则绑定事件，反之设置定时器使modal消失
    if(hasF) {
        I('modalY').onclick = function() {
            fadeOut(modal);
            f();
        };
        I('modalN').onclick = function() {
            fadeOut(modal);
        };
        I('modalM').onclick = function() {
            fadeOut(modal);
        };
    } else {
        mdTime = setTimeout(function() { fadeOut(modal); }, 2000);
    }
}

function N(n, s) {
    return s ? document.getElementsByName(n) : document.getElementsByName(n)[0];
}

function T(t, s, f) {
    if(s) {
        return f ? f.getElementsByTagName(t) : document.getElementsByTagName(t);
    } else {
        return f ? f.getElementsByTagName(t)[0] : document.getElementsByTagName(t)[0];
    }
}

function I(i) {
    return document.getElementById(i);
}