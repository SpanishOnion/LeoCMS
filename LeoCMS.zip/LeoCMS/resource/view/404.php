<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>站点已经到期</title>
    <link href="http://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link href="http://cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <script src="http://cdn.bootcss.com/jquery/3.1.1/jquery.min.js"></script>
    <script src="http://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.js"></script>
</head>
<body>
<h1></h1>
<div class="container">
    <div class="panel panel-info">
        <div class="panel-heading">
            <h3 class="panel-title">温馨提示</h3>
        </div>
        <div class="panel-body">
            <h3>
                <i class="fa fa-info-circle"></i> 404 您请求的页面不存在
            </h3>
            <a href="{{__ROOT__}}" class="btn btn-default">
                <i class="fa fa-home"></i> 返回首页
            </a>
        </div>
        <div class="panel-footer">
            微信/桌面/移动全能建站系统 <a href="http://www.hdcms.com">www.hdcms.com</a>
        </div>
    </div>
</div>
</body>
</html>