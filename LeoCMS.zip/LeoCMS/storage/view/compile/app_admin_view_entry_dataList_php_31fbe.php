<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>首页</title>
        <link rel="stylesheet" href="./resource/css/admin/bootstrap.min.css">
        <link rel="stylesheet" href="./resource/css/admin/common.css">
        <link rel="shortcut icon" href="./favicon.ico">
        <script src="./resource/font/admin/icon/iconfont.js"></script>
    </head>
    <body>
        <!--头部-->
        <header class="alert headInfo">
            <a class="headTitle" href="index.php?s=admin/Entry/index">
                <span class="title-letter">
                    Leo<span class="colorful-0">C</span><span class="colorful-1">M</span><span class="colorful-2">S</span>
                </span>
                <span>后台管理系统</span>
            </a>
            <div class="head-mid">
                <a class="headTitle title-manual title-config" href="index.php?s=admin/Entry/config">
                    <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-icon_xitongguanli"></use>
                    </svg>
                    网站配置
                </a>
                <a class="headTitle title-manual title-config" href="index.php?s=admin/Entry/dataList">
                    <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-hdm"></use>
                    </svg>
                    备份数据
                </a>
                <a class="headTitle title-manual title-config title-module" href="index.php?s=module/Module/index">
                    <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-iconsheji-"></use>
                    </svg>
                    模块管理
                </a>
                <a class="headTitle title-manual title-config title-wechat" href="index.php?s=wechat/Config/index">
                    <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-weixin"></use>
                    </svg>
                    <span>微信系统管理</span>
                </a>
                <a class="headTitle title-manual title-muan" href="http://doc.hdphp.com/215149" target="_blank">
                    <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-bangzhushouce"></use>
                    </svg>
                    <span>开发手册</span>
                </a>
                <a class="headTitle title-manual title-config title-icon" href="http://iconfont.cn/home/index?spm=a313x.7781069.1998910419.2" target="_blank">
                <svg class="icon icon-house" aria-hidden="true">
                    <use xlink:href="#icon-xingxing"></use>
                </svg>
                图标库
            </a>

            </div>
            <?php if(Session::has('cmsAdmin')) { ?>
                <div class="headUser">
                    <span>Hi，</span>
                    <span class="username"><?php echo Session::get('cmsAdmin'); ?></span>
                    <span>！欢迎回来 ~</span>
                    <button class="btn btn-danger btn-signOut">退出</button>
                    <button class="btn btn-primary btn-switch">切换账号</button>
                </div>
            <?php } ?>
        </header>
        <!--头部end-->
        <!-- 菜单栏 -->
        <div class="col-xs-12 col-sm-3 col-lg-2 left-menu">
            <div class="panel panel-default" id="menus">
                <!--学院管理-->
                <details><summary><span>用户管理</span></summary></details>
                <ul class="menus">
                    <li>
                        <a href="index.php?s=admin/User/index">
                            <svg class="icon" aria-hidden="true"><use xlink:href="#icon-drxx08"></use></svg>
                            管理员列表
                        </a>
                    </li>
                </ul>
                <!--分类管理-->
                <details><summary><span>分类管理</span></summary></details>
                <ul class="menus">
                    <li>
                        <a href="index.php?s=admin/Category/index">
                            <svg class="icon" aria-hidden="true"><use xlink:href="#icon-icon_hangyefenlei"></use></svg>
                            分类列表
                        </a>
                    </li>
                </ul>
                <!--文章管理-->
                <details><summary><span>文章管理</span></summary></details>
                <ul class="menus menus-m">
                    <li>
                        <a href="index.php?s=admin/Article/index">
                            <svg class="icon" aria-hidden="true"><use xlink:href="#icon-liebiaocaidan"></use></svg>
                            文章列表
                        </a>
                    </li>
                    <li>
                        <a href="index.php?s=admin/Article/recycle">
                            <svg class="icon" aria-hidden="true"><use xlink:href="#icon-recyclebin"></use></svg>
                            回收站
                        </a>
                    </li>
                </ul>
                <!--图片管理-->
                <details><summary><span>图片管理</span></summary></details>
                <ul class="menus">
                    <li>
                        <a href="index.php?s=admin/Photo/index">
                            <svg class="icon" aria-hidden="true"><use xlink:href="#icon-tupian"></use></svg>
                            轮播图列表
                        </a>
                    </li>
                </ul>
                <!--扩展模块-->
                <?php foreach($vnData as $k=>$v){ ?>
                    <div id="vn<?php echo $v['id']; ?>">
                        <details><summary><span><?php echo $v['name']; ?></span></summary></details>
                        <ul class="menus">
                            <li>
                                <a href="index.php?a=<?php echo $v['itf']; ?>/Entry/index">
                                    <svg class="icon" aria-hidden="true"><use xlink:href="#icon-tupian"></use></svg>
                                    <?php echo $v['name']; ?>首页
                                </a>
                            </li>
                        </ul>
                    </div>
                <?php } ?>
            </div>
        </div>
        <!-- 菜单栏end -->
        
    <div class="form-list container form-list-main">
        <div class="alert headInfo atcHead">
            <div class="alllog" >
                <button class="btn btn-default" id="backup">
                    <svg class="icon" aria-hidden="true" style="font-size:20px">
                        <use xlink:href="#icon-yunduanbeifen"></use>
                    </svg>
                    <span>一键备份数据库</span>
                </button>
            </div>
        </div>
        <table class="table table-hover">
            <tbody id="tbd">
                <tr>
                    <th>序号</th>
                    <th>备份数据所在目录</th>
                    <th>备份时间</th>
                    <th>操作</th>
                </tr>
                <?php foreach($data as $k=>$v){ ?>
                    <tr data-id="">
                        <td><?php echo $k + 1; ?></td>
                        <td><?php echo __ROOT__, '/' ;?><span><?php echo 'backup/', $v['filename']; ?></span></td>
                        <td><?php echo date('Y-m-d H:i:s', $v['filemtime']);?></td>
                        <td>
                            <button class="btn btn-success btn-xs rdc">一键恢复</button>
                            <button class="btn btn-danger btn-xs del">删除备份数据</button>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <hr>
    </div>
    <!--添加账号表单-->
    <div class="modelFrames">
        <div class="modelFrame frames-small">
            <div class="form-group">
                <label>管理员昵称</label>
                <input class="form-control" name="nickname" type="text" value="">
            </div>
            <div class="form-group">
                <label>管理员账号</label>
                <input class="form-control" name="username" type="text" value="">
            </div>
            <div class="form-group">
                <label>管理员密码</label>
                <input class="form-control skip" name="password" type="password" value="">
            </div>
            <input class="form-control addTime" name="ltime" type="hidden" value="">
            <button class="btn btn-info btn-block btn-ajax-edit">立刻添加</button>
            <button class="btn btn-block btn-cancel">取消</button>
        </div>
        <div class="mask"></div>
    </div>

    <!--修改密码表单-->
    <div class="modelFrames">
        <div class="modelFrame frames-small">
            <div class="form-group">
                <label>管理员账号</label>
                <input class="form-control" name="username" type="text" value="">
            </div>
            <div class="form-group">
                <label>管理员密码</label>
                <input class="form-control skip" name="password" type="password" value="">
            </div>
            <div class="form-group">
                <label>管理员密码</label>
                <input class="form-control skip" name="password" type="password" value="">
            </div>
            <div class="form-group">
                <label>所属分类</label>
                <select class="form-control" name="cid">
                    <option value="">请选择所属分类</option>
                    <option value="">顶级分类</option>
                </select>
            </div>
            <input class="form-control addTime" name="ltime" type="hidden" value="">
            <button class="btn btn-info btn-block btn-ajax-edit">立刻添加</button>
            <button class="btn btn-block btn-cancel">取消</button>
        </div>
        <div class="mask"></div>
    </div>

        <div class="body-bg"></div>
        <footer>Copyright© 2017-2018 李聪 Leo 个人博客 版权所有</footer>
        <script src="./resource/js/common/helper.js"></script>
        <?php if (v('mo') == 'admin') { ?>
            <script src="./resource/js/admin/master.js"></script>
        <?php } ?>
        <?php if (v('co') == 'User') { ?>
            <script src="./resource/js/admin/user/index.js"></script>
        <?php } else if (v('ac') == 'dataList') { ?>
            <script src="./resource/js/admin/Entry/dataList.js"></script>
        <?php } else if (v('co') == 'Category') { ?>
            <script src="./resource/js/admin/category/index.js"></script>
        <?php } else if (v('co') == 'Article') { ?>
            <script src="./resource/js/admin/KindEditor/kindeditor.js"></script>
            <script src="./resource/js/admin/KindEditor/lang/zh_CN.js"></script>
            <!--后盾全家桶-->
            <script src="<?php echo htmlspecialchars(__ROOT__)?>/resource/hdjs/app/util.js"></script>
            <script src="<?php echo htmlspecialchars(__ROOT__)?>/resource/hdjs/require.js"></script>
            <script src="<?php echo htmlspecialchars(__ROOT__)?>/resource/hdjs/app/config.js"></script>
            <!--后盾全家桶end-->
            <script src="./resource/js/admin/article/index.js"></script>
        <?php } else if (v('co') == 'Module') { ?>
            <script src="./resource/js/wechat/master.js"></script>
            <script src="./resource/js/module/module/index.js"></script>
        <?php } ?>
    </body>
</html>
