<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta name="description" content="">
		<meta name="author" content="">
		<title>Newspaper</title>
		<!-- Bootstrap Core CSS -->
		<link rel="stylesheet" href="<?php echo $tplPath; ?>/css/bootstrap.min.css"  type="text/css">
		<!-- Custom CSS -->
		<link rel="stylesheet" href="<?php echo $tplPath; ?>/css/style.css">
		<!-- Owl Carousel Assets -->
		<link href="<?php echo $tplPath; ?>/owl-carousel/owl.carousel.css" rel="stylesheet">
		<link href="<?php echo $tplPath; ?>/owl-carousel/owl.theme.css" rel="stylesheet">
		<!-- Custom Fonts -->
		<link rel="stylesheet" href="<?php echo $tplPath; ?>/font-awesome-4.4.0/css/font-awesome.min.css"  type="text/css">
	</head>
	<body>
	<header>
		<!--Top-->
		<nav id="top">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						<strong>Welcome to Us!</strong>
					</div>
					<div class="col-md-6">
						<ul class="list-inline top-link link">
							<li><a href="<?php echo $tplPath; ?>/index.html"><i class="fa fa-home"></i> Home</a></li>
							<li><a href="<?php echo $tplPath; ?>/contact.html"><i class="fa fa-comments"></i> Contact</a></li>
							<li><a href="<?php echo $tplPath; ?>/#"><i class="fa fa-question-circle"></i> FAQ</a></li>
						</ul>
					</div>
				</div>
			</div>
		</nav>

		<!--Navigation-->
		<nav id="menu" class="navbar container">
			<div class="navbar-header">
				<button type="button" class="btn btn-navbar navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse"><i class="fa fa-bars"></i></button>
				<a class="navbar-brand" href="<?php echo $tplPath; ?>/#">
					<div class="logo"><span>Newspaper</span></div>
				</a>
			</div>
			<div class="collapse navbar-collapse navbar-ex1-collapse">
				<ul class="nav navbar-nav">
					<li><a href="./">Home</a></li>
					<li class="dropdown"><a href="<?php echo $tplPath; ?>/#" class="dropdown-toggle" data-toggle="dropdown">Login <i class="fa fa-arrow-circle-o-down"></i></a>
						<div class="dropdown-menu">
							<div class="dropdown-inner">
								<ul class="list-unstyled">
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 101</a></li>
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 102</a></li>
								</ul>
							</div>
						</div>
					</li>
					<li class="dropdown"><a href="<?php echo $tplPath; ?>/#" class="dropdown-toggle" data-toggle="dropdown">Video <i class="fa fa-arrow-circle-o-down"></i></a>
						<div class="dropdown-menu">
							<div class="dropdown-inner">
								<ul class="list-unstyled">
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 201</a></li>
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 202</a></li>
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 203</a></li>
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 204</a></li>
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 205</a></li>
								</ul>
							</div>
						</div>
					</li>
					<li class="dropdown"><a href="<?php echo $tplPath; ?>/#" class="dropdown-toggle" data-toggle="dropdown">Category <i class="fa fa-arrow-circle-o-down"></i></a>
						<div class="dropdown-menu" style="margin-left: -203.625px;">
							<div class="dropdown-inner">
								<ul class="list-unstyled">
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 301</a></li>
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 302</a></li>
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 303</a></li>
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 304</a></li>
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 305</a></li>
								</ul>
								<ul class="list-unstyled">
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 306</a></li>
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 307</a></li>
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 308</a></li>
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 309</a></li>
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 310</a></li>
								</ul>
								<ul class="list-unstyled">
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 311</a></li>
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 312</a></li>
									<li><a href="<?php echo $tplPath; ?>/archive.html#">Text 313</a></li>
									<li><a href="<?php echo $tplPath; ?>/archive.html#">Text 314</a></li>
									<li><a href="<?php echo $tplPath; ?>/archive.html">Text 315</a></li>
								</ul>
							</div>
						</div>
					</li>
					<li><a href="<?php echo $tplPath; ?>/archive.html"><i class="fa fa-cubes"></i> Blocks</a></li>
					<li><a href="<?php echo $tplPath; ?>/contact.html"><i class="fa fa-envelope"></i> Contact</a></li>
				</ul>
				<ul class="list-inline navbar-right top-social">
					<li><a href="<?php echo $tplPath; ?>/#"><i class="fa fa-facebook"></i></a></li>
					<li><a href="<?php echo $tplPath; ?>/#"><i class="fa fa-twitter"></i></a></li>
					<li><a href="<?php echo $tplPath; ?>/#"><i class="fa fa-pinterest"></i></a></li>
					<li><a href="<?php echo $tplPath; ?>/#"><i class="fa fa-google-plus-square"></i></a></li>
					<li><a href="<?php echo $tplPath; ?>/#"><i class="fa fa-youtube"></i></a></li>
				</ul>
			</div>
		</nav>
	</header>
		<div class="featured container">
			<div id="owl-demo" class="owl-carousel">
				<div class="item">
					<div class="zoom-container">
						<div class="zoom-caption">
							<span>Youtube</span>
							<a href="<?php echo $tplPath; ?>/single.html">
								<i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
							</a>
							<p>Video's Name</p>
						</div>
						<img src="<?php echo $tplPath; ?>/images/1.jpg" />
					</div>
				</div>
				<div class="item">
					<div class="zoom-container">
						<div class="zoom-caption">
							<span>Youtube</span>
							<a href="<?php echo $tplPath; ?>/single.html">
								<i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
							</a>
							<p>Video's Name</p>
						</div>
						<img src="<?php echo $tplPath; ?>/images/2.jpg" />
					</div>
				</div>
				<div class="item">
					<div class="zoom-container">
						<div class="zoom-caption">
							<span>Youtube</span>
							<a href="<?php echo $tplPath; ?>/single.html">
								<i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
							</a>
							<p>Video's Name</p>
						</div>
						<img src="<?php echo $tplPath; ?>/images/3.jpg" />
					</div>
				</div>
				<div class="item">
					<div class="zoom-container">
						<div class="zoom-caption">
							<span>Youtube</span>
							<a href="<?php echo $tplPath; ?>/single.html">
								<i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
							</a>
							<p>Video's Name</p>
						</div>
						<img src="<?php echo $tplPath; ?>/images/8.jpg" />
					</div>
				</div>
				<div class="item">
					<div class="zoom-container">
						<div class="zoom-caption">
							<span>Youtube</span>
							<a href="<?php echo $tplPath; ?>/single.html">
								<i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
							</a>
							<p>Video's Name</p>
						</div>
						<img src="<?php echo $tplPath; ?>/images/9.jpg" />
					</div>
				</div>
				<div class="item">
					<div class="zoom-container">
						<div class="zoom-caption">
							<span>Youtube</span>
							<a href="<?php echo $tplPath; ?>/single.html">
								<i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
							</a>
							<p>Video's Name</p>
						</div>
						<img src="<?php echo $tplPath; ?>/images/10.jpg" />
					</div>
				</div>
				<div class="item">
					<div class="zoom-container">
						<div class="zoom-caption">
							<span>Youtube</span>
							<a href="<?php echo $tplPath; ?>/single.html">
								<i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
							</a>
							<p>Video's Name</p>
						</div>
						<img src="<?php echo $tplPath; ?>/images/11.jpg" />
					</div>
				</div>
				<div class="item">
					<div class="zoom-container">
						<div class="zoom-caption">
							<span>Youtube</span>
							<a href="<?php echo $tplPath; ?>/single.html">
								<i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
							</a>
							<p>Video's Name</p>
						</div>
						<img src="<?php echo $tplPath; ?>/images/12.jpg" />
					</div>
				</div>
			</div>
		</div>
		<!-- Header -->
		<!-- /////////////////Content -->
		<div id="page-content" class="archive-page container">
			<div class="">
				<div class="row">
					<div id="main-content" class="col-md-8">
						<div class="box">
							<a href="<?php echo $tplPath; ?>/#"><h2 class="vid-name">Lorem ipsum dolor sit amet</h2></a>
							<div class="info">
								<h5>By <a href="<?php echo $tplPath; ?>/#">Kelvin</a></h5>
								<span><i class="fa fa-calendar"></i> June 12, 2015</span>
								<span><i class="fa fa-comment"></i> 0 Comments</span>
								<span><i class="fa fa-heart"></i>1,200</span>
								<ul class="list-inline">
									<li><a href="<?php echo $tplPath; ?>/#">Rate</a></li>
									<li> - </li>
									<li>
										<span class="rating">
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star-half-o"></i>
										</span>
									</li>
								</ul>
							</div>
							<div class="wrap-vid">
								<div class="zoom-container">
									<div class="zoom-caption">
									</div>
									<img src="<?php echo $tplPath; ?>/images/9.jpg" />
								</div>
								<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Consetetur sadipscing elitr, sed diam nonumy eirmod tempor inviduntut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.justo duo dolores et ea rebum. Consetetur sadipscing elitr,  consetetur sadipscing elitr elitr. <a href="<?php echo $tplPath; ?>/#">MORE...</a></p>
							</div>
						</div>
						<hr class="line">
						<div class="box">
							<a href="<?php echo $tplPath; ?>/#"><h2 class="vid-name">Lorem ipsum dolor sit amet</h2></a>
							<div class="info">
								<h5>By <a href="<?php echo $tplPath; ?>/#">Kelvin</a></h5>
								<span><i class="fa fa-calendar"></i> June 12, 2015</span>
								<span><i class="fa fa-comment"></i> 0 Comments</span>
								<span><i class="fa fa-heart"></i>1,200</span>
								<ul class="list-inline">
									<li><a href="<?php echo $tplPath; ?>/#">Rate</a></li>
									<li> - </li>
									<li>
										<span class="rating">
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star-half-o"></i>
										</span>
									</li>
								</ul>
							</div>
							<div class="wrap-vid">
								<div class="zoom-container">
									<div class="zoom-caption">
									</div>
									<img src="<?php echo $tplPath; ?>/images/7.jpg" />
								</div>
								<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Consetetur sadipscing elitr, sed diam nonumy eirmod tempor inviduntut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.justo duo dolores et ea rebum. Consetetur sadipscing elitr,  consetetur sadipscing elitr elitr. <a href="<?php echo $tplPath; ?>/#">MORE...</a></p>
							</div>
						</div>
						<hr class="line">
						<div class="box">
							<a href="<?php echo $tplPath; ?>/#"><h2 class="vid-name">Lorem ipsum dolor sit amet</h2></a>
							<div class="info">
								<h5>By <a href="<?php echo $tplPath; ?>/#">Kelvin</a></h5>
								<span><i class="fa fa-calendar"></i> June 12, 2015</span>
								<span><i class="fa fa-comment"></i> 0 Comments</span>
								<span><i class="fa fa-heart"></i>1,200</span>
								<ul class="list-inline">
									<li><a href="<?php echo $tplPath; ?>/#">Rate</a></li>
									<li> - </li>
									<li>
										<span class="rating">
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star-half-o"></i>
										</span>
									</li>
								</ul>
							</div>
							<div class="wrap-vid">
								<div class="zoom-container">
									<div class="zoom-caption">
										<span class="youtube">Youtube</span>
										<a href="<?php echo $tplPath; ?>/single.html">
											<i class="fa fa-play icon-play" style="color: #fff"></i>
										</a>
										<p>Video's Name</p>
									</div>
									<img src="<?php echo $tplPath; ?>/images/8.jpg" />
								</div>
								<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Consetetur sadipscing elitr, sed diam nonumy eirmod tempor inviduntut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.justo duo dolores et ea rebum. Consetetur sadipscing elitr,  consetetur sadipscing elitr elitr. <a href="<?php echo $tplPath; ?>/#">MORE...</a></p>
							</div>
						</div>
						<hr class="line">
						<div class="box">
							<a href="<?php echo $tplPath; ?>/#"><h2 class="vid-name">Lorem ipsum dolor sit amet</h2></a>
							<div class="info">
								<h5>By <a href="<?php echo $tplPath; ?>/#">Kelvin</a></h5>
								<span><i class="fa fa-calendar"></i> June 12, 2015</span>
								<span><i class="fa fa-comment"></i> 0 Comments</span>
								<span><i class="fa fa-heart"></i>1,200</span>
								<ul class="list-inline">
									<li><a href="<?php echo $tplPath; ?>/#">Rate</a></li>
									<li> - </li>
									<li>
										<span class="rating">
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star-half-o"></i>
										</span>
									</li>
								</ul>
							</div>
							<div class="wrap-vid">
								<div class="zoom-container">
									<div class="zoom-caption">
										<span class="vimeo">Vimeo</span>
										<a href="<?php echo $tplPath; ?>/single.html">
											<i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
										</a>
										<p>Video's Name</p>
									</div>
									<img src="<?php echo $tplPath; ?>/images/6.jpg" />
								</div>
								<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Consetetur sadipscing elitr, sed diam nonumy eirmod tempor inviduntut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.justo duo dolores et ea rebum. Consetetur sadipscing elitr,  consetetur sadipscing elitr elitr. <a href="<?php echo $tplPath; ?>/#">MORE...</a></p>
							</div>
						</div>
						<hr class="line">
						<div class="box">
							<center>
							<ul class="pagination">
								<li>
								  <a href="<?php echo $tplPath; ?>/#" aria-label="Previous">
									<span aria-hidden="true">&laquo;</span>
								  </a>
								</li>
								<li><a href="<?php echo $tplPath; ?>/#">1</a></li>
								<li><a href="<?php echo $tplPath; ?>/#">2</a></li>
								<li><a href="<?php echo $tplPath; ?>/#">3</a></li>
								<li><a href="<?php echo $tplPath; ?>/#">4</a></li>
								<li><a href="<?php echo $tplPath; ?>/#">5</a></li>
								<li>
								  <a href="<?php echo $tplPath; ?>/#" aria-label="Next">
									<span aria-hidden="true">&raquo;</span>
								  </a>
								</li>
							</ul>
						</center>
						</div>
					</div>
					<div id="sidebar" class="col-md-4">
						<!---- Start Widget ---->
						<div class="widget wid-follow">
							<div class="heading"><h4>Follow Us</h4></div>
							<div class="content">
								<ul class="list-inline">
									<li>
										<a href="<?php echo $tplPath; ?>/facebook.com/">
											<div class="box-facebook">
												<span class="fa fa-facebook fa-2x icon"></span>
												<span>1250</span>
												<span>Fans</span>
											</div>
										</a>
									</li>
									<li>
										<a href="<?php echo $tplPath; ?>/facebook.com/">
											<div class="box-twitter">
												<span class="fa fa-twitter fa-2x icon"></span>
												<span>1250</span>
												<span>Fans</span>
											</div>
										</a>
									</li>
									<li>
										<a href="<?php echo $tplPath; ?>/facebook.com/">
											<div class="box-google">
												<span class="fa fa-google-plus fa-2x icon"></span>
												<span>1250</span>
												<span>Fans</span>
											</div>
										</a>
									</li>
								</ul>
								<img src="<?php echo $tplPath; ?>/images/banner.jpg" />
							</div>
						</div>
						<!---- Start Widget ---->
						<div class="widget wid-post">
							<div class="heading"><h4>Category</h4></div>
							<div class="content">
								<div class="post wrap-vid">
									<div class="zoom-container">
										<div class="zoom-caption">
											<span class="youtube">Youtube</span>
											<a href="<?php echo $tplPath; ?>/single.html">
												<i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
											</a>
											<p>Video's Name</p>
										</div>
										<img src="<?php echo $tplPath; ?>/images/1.jpg" />
									</div>
									<div class="wrapper">
										<h5 class="vid-name"><a href="<?php echo $tplPath; ?>/#">Video's Name</a></h5>
										<div class="info">
											<h6>By <a href="<?php echo $tplPath; ?>/#">Kelvin</a></h6>
											<span><i class="fa fa-calendar"></i>25/3/2015</span>
											<span><i class="fa fa-heart"></i>1,200</span>
										</div>
									</div>
								</div>
								<div class="post wrap-vid">
									<div class="zoom-container">
												<div class="zoom-caption">
													<span class="vimeo">Vimeo</span>
													<a href="<?php echo $tplPath; ?>/single.html">
														<i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
													</a>
													<p>Video's Name</p>
												</div>
												<img src="<?php echo $tplPath; ?>/images/2.jpg" />
											</div>
									<div class="wrapper">
										<h5 class="vid-name"><a href="<?php echo $tplPath; ?>/#">Video's Name</a></h5>
										<div class="info">
											<h6>By <a href="<?php echo $tplPath; ?>/#">Kelvin</a></h6>
											<span><i class="fa fa-calendar"></i>25/3/2015</span>
											<span><i class="fa fa-heart"></i>1,200</span>
										</div>
									</div>
								</div>
								<div class="post wrap-vid">
									<div class="zoom-container">
										<div class="zoom-caption">
											<span class="youtube">Youtube</span>
											<a href="<?php echo $tplPath; ?>/single.html">
												<i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
											</a>
											<p>Video's Name</p>
										</div>
										<img src="<?php echo $tplPath; ?>/images/3.jpg" />
									</div>
									<div class="wrapper">
										<h5 class="vid-name"><a href="<?php echo $tplPath; ?>/#">Video's Name</a></h5>
										<div class="info">
											<h6>By <a href="<?php echo $tplPath; ?>/#">Kelvin</a></h6>
											<span><i class="fa fa-calendar"></i>25/3/2015</span>
											<span><i class="fa fa-heart"></i>1,200</span>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!---- Start Widget ---->
						<div class="widget ">
							<div class="heading"><h4>Top News</h4></div>
							<div class="content">
								<div class="wrap-vid">
									<div class="zoom-container">
										<div class="zoom-caption">
											<span class="vimeo">Vimeo</span>
											<a href="<?php echo $tplPath; ?>/single.html">
												<i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
											</a>
											<p>Video's Name</p>
										</div>
										<img src="<?php echo $tplPath; ?>/images/1.jpg" />
									</div>
									<h3 class="vid-name"><a href="<?php echo $tplPath; ?>/#">Video's Name</a></h3>
									<div class="info">
										<h5>By <a href="<?php echo $tplPath; ?>/#">Kelvin</a></h5>
										<span><i class="fa fa-calendar"></i>25/3/2015</span>
										<span><i class="fa fa-heart"></i>1,200</span>
									</div>
								</div>
								<div class="wrap-vid">
									<div class="zoom-container">
										<div class="zoom-caption">
											<span class="vimeo">Vimeo</span>
											<a href="<?php echo $tplPath; ?>/single.html">
												<i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
											</a>
											<p>Video's Name</p>
										</div>
										<img src="<?php echo $tplPath; ?>/images/2.jpg" />
									</div>
									<h3 class="vid-name"><a href="<?php echo $tplPath; ?>/#">Video's Name</a></h3>
									<div class="info">
										<h5>By <a href="<?php echo $tplPath; ?>/#">Kelvin</a></h5>
										<span><i class="fa fa-calendar"></i>25/3/2015</span>
										<span><i class="fa fa-heart"></i>1,200</span>
									</div>
								</div>
								<div class="wrap-vid">
									<div class="zoom-container">
										<div class="zoom-caption">
											<span class="vimeo">Vimeo</span>
											<a href="<?php echo $tplPath; ?>/single.html">
												<i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
											</a>
											<p>Video's Name</p>
										</div>
										<img src="<?php echo $tplPath; ?>/images/3.jpg" />
									</div>
									<h3 class="vid-name"><a href="<?php echo $tplPath; ?>/#">Video's Name</a></h3>
									<div class="info">
										<h5>By <a href="<?php echo $tplPath; ?>/#">Kelvin</a></h5>
										<span><i class="fa fa-calendar"></i>25/3/2015</span>
										<span><i class="fa fa-heart"></i>1,200</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<footer>
			<div class="wrap-footer">
				<div class="container">
					<div class="row">
						<div class="col-md-4 col-footer footer-1">
							<div class="footer-heading"><h1><span style="color: #fff;">NEWSPAPER</span></h1></div>
							<div class="content">
								<p>Never missed any post published in our site. Subscribe to our daly newsletter now.</p>
								<strong>Email address:</strong>
								<form action="#" method="post">
									<input type="text" name="your-name" value="" size="40" placeholder="Your Email" />
									<input type="submit" value="SUBSCRIBE" class="btn btn-3" />
								</form>
							</div>
						</div>
						<div class="col-md-4 col-footer footer-2">
							<div class="footer-heading"><h4>Tags</h4></div>
							<div class="content">
								<a href="<?php echo $tplPath; ?>/#">animals</a>
								<a href="<?php echo $tplPath; ?>/#">cooking</a>
								<a href="<?php echo $tplPath; ?>/#">countries</a>
								<a href="<?php echo $tplPath; ?>/#">city</a>
								<a href="<?php echo $tplPath; ?>/#">children</a>
								<a href="<?php echo $tplPath; ?>/#">home</a>
								<a href="<?php echo $tplPath; ?>/#">likes</a>
								<a href="<?php echo $tplPath; ?>/#">photo</a>
								<a href="<?php echo $tplPath; ?>/#">link</a>
								<a href="<?php echo $tplPath; ?>/#">law</a>
								<a href="<?php echo $tplPath; ?>/#">shopping</a>
								<a href="<?php echo $tplPath; ?>/#">skate</a>
								<a href="<?php echo $tplPath; ?>/#">scholl</a>
								<a href="<?php echo $tplPath; ?>/#">video</a>
								<a href="<?php echo $tplPath; ?>/#">travel</a>
								<a href="<?php echo $tplPath; ?>/#">images</a>
								<a href="<?php echo $tplPath; ?>/#">love</a>
								<a href="<?php echo $tplPath; ?>/#">lists</a>
								<a href="<?php echo $tplPath; ?>/#">makeup</a>
								<a href="<?php echo $tplPath; ?>/#">media</a>
								<a href="<?php echo $tplPath; ?>/#">password</a>
								<a href="<?php echo $tplPath; ?>/#">pagination</a>
								<a href="<?php echo $tplPath; ?>/#">wildlife</a>
							</div>
						</div>
						<div class="col-md-4 col-footer footer-3">
							<div class="footer-heading"><h4>Link List</h4></div>
							<div class="content">
								<ul>
									<li><a href="<?php echo $tplPath; ?>/#">MOST VISITED COUNTRIES</a></li>
									<li><a href="<?php echo $tplPath; ?>/#">5 PLACES THAT MAKE A GREAT HOLIDAY</a></li>
									<li><a href="<?php echo $tplPath; ?>/#">PEBBLE TIME STEEL IS ON TRACK TO SHIP IN JULY</a></li>
									<li><a href="<?php echo $tplPath; ?>/#">STARTUP COMPANY’S CO-FOUNDER TALKS ON HIS NEW PRODUCT</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="copy-right">
				<p>Copyright &copy; 2015.Company name All rights reserved.<a target="_blank" href="<?php echo $tplPath; ?>/http://www.cssmoban.com/">&#x7F51;&#x9875;&#x6A21;&#x677F;</a></p>
			</div>
		</footer>
		<!-- Footer -->
		<!-- JS -->
		<!-- jQuery and Modernizr-->
		<script src="<?php echo $tplPath; ?>/js/jquery-2.1.1.js"></script>
		<!-- Core JavaScript Files -->
		<script src="<?php echo $tplPath; ?>/js/bootstrap.min.js"></script>
		<!--[if lt IE 9]>
		<script src="<?php echo $tplPath; ?>/js/html5shiv.js"></script>
		<script src="<?php echo $tplPath; ?>/js/respond.min.js"></script>
		<![endif]-->
		<script src="<?php echo $tplPath; ?>/owl-carousel/owl.carousel.js"></script>
		<script>
		$(document).ready(function() {
		  $("#owl-demo").owlCarousel({
			autoPlay: 3000,
			items : 5,
			itemsDesktop : [1199,4],
			itemsDesktopSmall : [979,4]
		  });

		});
		</script>
	</body>
</html>
