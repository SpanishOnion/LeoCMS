<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Newspaper</title>
		<!-- Bootstrap Core CSS -->
		<link rel="stylesheet" href="<?php echo $tplPath; ?>css/bootstrap.min.css">
		<!-- Owl Carousel Assets -->
		<link rel="stylesheet" href="<?php echo $tplPath; ?>owl-carousel/owl.carousel.css">
		<link rel="stylesheet" href="<?php echo $tplPath; ?>owl-carousel/owl.theme.css">
		<!-- Custom CSS -->
		<link rel="stylesheet" href="<?php echo $tplPath; ?>css/style.css">
		<link rel="stylesheet" href="<?php echo $tplPath; ?>css/bootstrap-datetimepicker.min.css" media="screen">
		<!-- Custom Fonts -->
		<link rel="stylesheet" href="<?php echo $tplPath; ?>font-awesome-4.4.0/css/font-awesome.min.css">
	</head>
	<body>
		<header>
			<!--Top-->
			<nav id="top">
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<strong>Welcome to Us!</strong>
						</div>
						<div class="col-md-6">
							<ul class="list-inline top-link link">
								<li><a href="/"><i class="fa fa-home"></i> Home</a></li>
								<li><a href="<?php echo $tplPath; ?>contact.html"><i class="fa fa-comments"></i> Contact</a></li>
								<li><a href="<?php echo $tplPath; ?>#"><i class="fa fa-question-circle"></i> FAQ</a></li>
							</ul>
						</div>
					</div>
				</div>
			</nav>
			<!--Navigation-->
			<nav id="menu" class="navbar container">
				<div class="navbar-header">
					<button type="button" class="btn btn-navbar navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                        <i class="fa fa-bars"></i>
                    </button>
					<a class="navbar-brand" href="<?php echo $tplPath; ?>#">
						<div class="logo"><span>Newspaper</span></div>
					</a>
				</div>
				<div class="collapse navbar-collapse navbar-ex1-collapse">
					<ul class="nav navbar-nav">
						<li><a href="/">首页</a></li>
                        <?php foreach($cate as $k=>$v){ ?>
						<li class="dropdown">
                            <a href="/l/<?php echo $v['id']; ?>"><?php echo $v['name']; ?>电影
                                <i class="fa fa-arrow-circle-o-down"></i>
                            </a>
							<!--<div class="dropdown-menu">-->
								<!--<div class="dropdown-inner">-->
									<!--<ul class="list-unstyled">-->
										<!--<li><a href="<?php echo $tplPath; ?>archive.html">Login</a></li>-->
										<!--<li><a href="<?php echo $tplPath; ?>archive.html">Register</a></li>-->
									<!--</ul>-->
								<!--</div>-->
							<!--</div>-->
						</li>
                        <?php } ?>
					</ul>
					<ul class="list-inline navbar-right top-social">
						<li><a href="<?php echo $tplPath; ?>#"><i class="fa fa-facebook"></i></a></li>
						<li><a href="<?php echo $tplPath; ?>#"><i class="fa fa-twitter"></i></a></li>
						<li><a href="<?php echo $tplPath; ?>#"><i class="fa fa-pinterest"></i></a></li>
						<li><a href="<?php echo $tplPath; ?>#"><i class="fa fa-google-plus-square"></i></a></li>
						<li><a href="<?php echo $tplPath; ?>#"><i class="fa fa-youtube"></i></a></li>
					</ul>
				</div>
			</nav>
		</header>
		<div class="featured container">
			<div class="row">
				<div class="col-sm-8">
					<!-- Carousel -->
					<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
						<!-- Indicators -->
						<ol class="carousel-indicators">
							<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
							<li data-target="#carousel-example-generic" data-slide-to="1"></li>
							<li data-target="#carousel-example-generic" data-slide-to="2"></li>
						</ol>
						<!-- Wrapper for slides -->
						<div class="carousel-inner">
							<div class="item active">
								<img src="<?php echo $tplPath; ?>images/1.jpg" alt="First slide">
								<!-- Static Header -->
								<div class="header-text hidden-xs">
									<div class="col-md-12 text-center">
										<!--<h2>大标题 </h2>-->
										<br>
										<h3>小描述啊</h3>
										<br>
									</div>
								</div><!-- /header-text -->
							</div>
							<div class="item">
								<img src="<?php echo $tplPath; ?>images/2.jpg" alt="Second slide">
								<!-- Static Header -->
								<div class="header-text hidden-xs">
									<div class="col-md-12 text-center">
										<h2>Aenean feugiat in ante et blandit. Vestibulum</h2>
										<br>
										<h3>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h3>
										<br>
									</div>
								</div><!-- /header-text -->
							</div>
							<div class="item">
								<img src="<?php echo $tplPath; ?>images/3.jpg" alt="Third slide">
								<!-- Static Header -->
								<div class="header-text hidden-xs">
									<div class="col-md-12 text-center">
										<h2>Curabitur tincidunt porta lorem vitae</h2>
										<br>
										<h3>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h3>
										<br>
									</div>
								</div><!-- /header-text -->
							</div>
						</div>
						<!-- Controls -->
						<a class="left carousel-control" href="<?php echo $tplPath; ?>#carousel-example-generic" data-slide="prev">
							<span class="glyphicon glyphicon-chevron-left"></span>
						</a>
						<a class="right carousel-control" href="<?php echo $tplPath; ?>#carousel-example-generic" data-slide="next">
							<span class="glyphicon glyphicon-chevron-right"></span>
						</a>
					</div><!-- /carousel -->
				</div>
				<div class="col-sm-4" >
					<div id="owl-demo-1" class="owl-carousel">
						<img src="<?php echo $tplPath; ?>images/slide-2.jpg" />
						<img src="<?php echo $tplPath; ?>images/slide-1.jpg" />
						<img src="<?php echo $tplPath; ?>images/slide-3.jpg" />
					</div>
					<img src="<?php echo $tplPath; ?>images/banner.jpg" />
				</div>
			</div>
		</div>
		<!-- /////////////////////////////////////////Content -->
		<div id="page-content" class="index-page container">
			<div class="row">
				<div id="main-content"><!-- background not working -->
					<div class="col-md-6">
						<div class="box wrap-vid">
							<div class="zoom-container">
								<div class="zoom-caption">
									<span class="youtube">最新</span>
									<a href="/<?php echo $first['id']; ?>">
										<i class="f fa fa-play icon-play"></i>
									</a>
									<p><?php echo $first['digest']; ?></p>
								</div>
								<img class="fr-img" src="<?php echo $first['thumb']; ?>">
							</div>
							<h3 class="vid-name"><a href="/<?php echo $first['id']; ?>"><?php echo $first['title']; ?></a></h3>
							<div class="info">
								<h5>By <a href=""><?php echo $first['author']; ?></a></h5>
								<span><i class="fa fa-calendar"></i><?php echo date('Y-m-d H:i:s', $first['adtime']); ?></span>
								<span><i class="fa fa-heart"></i><?php echo $first['click']; ?></span>
							</div>
							<p class="more"><?php echo $first['digest']; ?></p>
						</div>
						<div class="box">
							<div class="box-header header-vimeo">
								<h2>评分最高</h2>
							</div>
							<div class="box-content">
								<div class="row">
									<div class="col-md-6">
										<div class="wrap-vid">
											<div class="zoom-container">
												<div class="zoom-caption">
													<span class="vimeo">Vimeo</span>
													<a href="<?php echo $tplPath; ?>single.html">
														<i class="fa fa-play-circle-o fa-5x" style="color: #fff"></i>
													</a>
													<p>Video's Name</p>
												</div>
												<img src="<?php echo $tplPath; ?>images/2.jpg" />
											</div>
											<h3 class="vid-name"><a href="<?php echo $tplPath; ?>#">Video's Name</a></h3>
											<div class="info">
												<h5>By <a href="<?php echo $tplPath; ?>#">Kelvin</a></h5>
												<span><i class="fa fa-calendar"></i>25/3/2015</span>
												<span><i class="fa fa-heart"></i>1,200</span>
											</div>
										</div>
										<p class="more">Aenean feugiat in ante et blandit. Vestibulum posuere molestie risus, ac interdum magna porta non. Pellentesque rutrum fringilla elementum. Curabitur tincidunt porta lorem vitae accumsan.</p>
									</div>
									<div class="col-md-6">
										<div class="post wrap-vid">
											<div class="zoom-container">
												<div class="zoom-caption">
													<span class="vimeo">Vimeo</span>
													<a href="<?php echo $tplPath; ?>single.html">
														<i class="fa fa-play-circle-o fa-3x" style="color: #fff"></i>
													</a>
													<p>Video's Name</p>
												</div>
												<img src="<?php echo $tplPath; ?>images/1.jpg" />
											</div>
											<div class="wrapper">
												<h5 class="vid-name"><a href="<?php echo $tplPath; ?>#">Video's Name</a></h5>
												<div class="info">
													<h6>By <a href="<?php echo $tplPath; ?>#">Kelvin</a></h6>
													<span><i class="fa fa-heart"></i>1,200 / <i class="fa fa-calendar"></i>25/3/2015</span>
													<span class="rating">
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star-half"></i>
													</span>
												</div>
											</div>
										</div>
										<div class="post wrap-vid">
											<div class="zoom-container">
												<div class="zoom-caption">
													<span class="vimeo">Vimeo</span>
													<a href="<?php echo $tplPath; ?>single.html">
														<i class="fa fa-play-circle-o fa-3x" style="color: #fff"></i>
													</a>
													<p>Video's Name</p>
												</div>
												<img src="<?php echo $tplPath; ?>images/2.jpg" />
											</div>
											<div class="wrapper">
												<h5 class="vid-name"><a href="<?php echo $tplPath; ?>#">Video's Name</a></h5>
												<div class="info">
													<h6>By <a href="<?php echo $tplPath; ?>#">Kelvin</a></h6>
													<span><i class="fa fa-heart"></i>1,200 / <i class="fa fa-calendar"></i>25/3/2015</span>
													<span class="rating">
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
													</span>
												</div>
											</div>
										</div>
										<div class="post wrap-vid">
											<div class="zoom-container">
												<div class="zoom-caption">
													<span class="vimeo">Vimeo</span>
													<a href="<?php echo $tplPath; ?>single.html">
														<i class="fa fa-play-circle-o fa-3x" style="color: #fff"></i>
													</a>
													<p>Video's Name</p>
												</div>
												<img src="<?php echo $tplPath; ?>images/3.jpg" />
											</div>
											<div class="wrapper">
												<h5 class="vid-name"><a href="<?php echo $tplPath; ?>#">Video's Name</a></h5>
												<div class="info">
													<h6>By <a href="<?php echo $tplPath; ?>#">Kelvin</a></h6>
													<span><i class="fa fa-heart"></i>1,200 / <i class="fa fa-calendar"></i>25/3/2015</span>
													<span class="rating">
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star-half"></i>
													</span>
												</div>
											</div>
										</div>
										<div class="post wrap-vid">
											<div class="zoom-container">
												<div class="zoom-caption">
													<span class="vimeo">Vimeo</span>
													<a href="<?php echo $tplPath; ?>single.html">
														<i class="fa fa-play-circle-o fa-3x" style="color: #fff"></i>
													</a>
													<p>Video's Name</p>
												</div>
												<img src="<?php echo $tplPath; ?>images/1.jpg" />
											</div>
											<div class="wrapper">
												<h5 class="vid-name"><a href="<?php echo $tplPath; ?>#">Video's Name</a></h5>
												<div class="info">
													<h6>By <a href="<?php echo $tplPath; ?>#">Kelvin</a></h6>
													<span><i class="fa fa-heart"></i>1,200 / <i class="fa fa-calendar"></i>25/3/2015</span>
													<span class="rating">
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star-half"></i>
													</span>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="box">
							<div class="box-header header-photo">
								<h2>经典台词</h2>
							</div>
							<div class="box-content">
								<div id="owl-demo-2" class="owl-carousel">
									<div class="item">
										<img src="<?php echo $tplPath; ?>images/1.jpg" />
										<img src="<?php echo $tplPath; ?>images/2.jpg" />
									</div>
									<div class="item">
										<img src="<?php echo $tplPath; ?>images/3.jpg" />
										<img src="<?php echo $tplPath; ?>images/5.jpg" />
									</div>
									<div class="item">
										<img src="<?php echo $tplPath; ?>images/8.jpg" />
										<img src="<?php echo $tplPath; ?>images/9.jpg" />
									</div>
									<div class="item">
										<img src="<?php echo $tplPath; ?>images/10.jpg" />
										<img src="<?php echo $tplPath; ?>images/11.jpg" />
									</div>
									<div class="item">
										<img src="<?php echo $tplPath; ?>images/12.jpg" />
										<img src="<?php echo $tplPath; ?>images/13.jpg" />
									</div>
								</div>
							</div>
						</div>
						<div class="box">
							<div class="box-header header-natural">
								<h2>点击排行</h2>
							</div>
							<div class="box-content">
								<div class="row">
                                    <?php foreach($click as $k=>$v){ ?>
									<div class="col-md-6">
										<img src="<?php echo $v['thumb']; ?>">
										<h3><a href="/<?php echo $v['id']; ?>"><?php echo $v['title']; ?></a></h3>
										<span><i class="fa fa-heart"></i> <?php echo $v['click']; ?> / <i class="fa fa-calendar"></i> <?php echo date('Y-m-d', $v['adtime']); ?> / <i class="fa fa-comment-o"> / </i> 10 <i class="fa fa-eye"></i> <?php echo $v['click']; ?></span>
										<span class="rating">
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star-half"></i>
										</span>
										<p>Marshall, Will, and Holly on a routine expedition, met the greatest earthquake ever known. High on the rapids, it struck their tiny raft! And plunged them down a thousand feet below…...</p>
									</div>
									<?php } ?>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div id="sidebar">
					<div class="col-md-3">
						<!---- Start Widget NEW POSTS ---->
						<?php foreach($cateList as $v){ ?>
						<a href="/<?php echo $v['id']; ?>">
							<div class="widget wid-new-post">
								<div class="heading"><h4><?php echo $v['name']; ?></h4></div>
								<div class="content">
									<h6><?php echo $v['title']; ?></h6>
									<img src="/<?php echo $v['thumb']; ?>">
									<ul class="list-inline">
										<li><i class="fa fa-calendar"></i><?php echo date('Y-m-d',$v['adtime']); ?></li>
										<li><i class="fa fa-comments"></i><?php echo $v['click']; ?></li>
									</ul>
									<p><?php echo $v['digest']; ?></p>
								</div>
							</div>
						</a>
						<?php } ?>
					</div>
					<div class="col-md-3">
						<!---- Start Widget ---->
						<div class="widget wid-tags">
							<div class="heading"><h4>Search</h4></div>
							<div class="content">
								<form role="form" class="form-horizontal" method="get" action="/l/1">
									<input class="form-control" name="search" type="text" value="" placeholder="Enter Search Keywords">
								</form>
							</div>
						</div>
						<!---- Start Widget ---->
						<div class="widget wid-tags">
							<div class="heading"><h4>Tags</h4></div>
							<div class="content">
								<a href="<?php echo $tplPath; ?>#">animals</a>
								<a href="<?php echo $tplPath; ?>#">cooking</a>
								<a href="<?php echo $tplPath; ?>#">countries</a>
								<a href="<?php echo $tplPath; ?>#">home</a>
								<a href="<?php echo $tplPath; ?>#">likes</a>
								<a href="<?php echo $tplPath; ?>#">photo</a>
								<a href="<?php echo $tplPath; ?>#">link</a>
								<a href="<?php echo $tplPath; ?>#">video</a>
								<a href="<?php echo $tplPath; ?>#">travel</a>
								<a href="<?php echo $tplPath; ?>#">images</a>
								<a href="<?php echo $tplPath; ?>#">love</a>
								<a href="<?php echo $tplPath; ?>#">lists</a>
								<a href="<?php echo $tplPath; ?>#">makeup</a>
								<a href="<?php echo $tplPath; ?>#">media</a>
								<a href="<?php echo $tplPath; ?>#">password</a>
								<a href="<?php echo $tplPath; ?>#">pagination</a>
								<a href="<?php echo $tplPath; ?>#">pictures</a>
							</div>
						</div>
						<!---- Start Widget ---->
						<div class="widget wid-comment">
							<div class="heading"><h4>Top Comments</h4></div>
							<div class="content">
								<div class="post">
									<a href="<?php echo $tplPath; ?>single.html">
										<img src="<?php echo $tplPath; ?>images/ava-1.jpg" class="img-circle"/>
									</a>
									<div class="wrapper">
										<a href="<?php echo $tplPath; ?>#"><h5>Curabitur tincidunt porta lorem.</h5></a>
										<ul class="list-inline">
											<li><i class="fa fa-calendar"></i>25/3/2015</li>
											<li><i class="fa fa-thumbs-up"></i>1,200</li>
										</ul>
									</div>
								</div>
								<div class="post">
									<a href="<?php echo $tplPath; ?>single.html">
										<img src="<?php echo $tplPath; ?>images/ava-2.png" class="img-circle"/>
									</a>
									<div class="wrapper">
										<a href="<?php echo $tplPath; ?>#"><h5>Curabitur tincidunt porta lorem.</h5></a>
										<ul class="list-inline">
											<li><i class="fa fa-calendar"></i>25/3/2015</li>
											<li><i class="fa fa-thumbs-up"></i>1,200</li>
										</ul>
									</div>
								</div>
								<div class="post">
									<a href="<?php echo $tplPath; ?>single.html">
										<img src="<?php echo $tplPath; ?>images/ava-3.jpeg" class="img-circle"/>
									</a>
									<div class="wrapper">
										<a href="<?php echo $tplPath; ?>#"><h5>Curabitur tincidunt porta lorem.</h5></a>
										<ul class="list-inline">
											<li><i class="fa fa-calendar"></i>25/3/2015</li>
											<li><i class="fa fa-thumbs-up"></i>1,200</li>
										</ul>
									</div>
								</div>
								<div class="post">
									<a href="<?php echo $tplPath; ?>single.html">
										<img src="<?php echo $tplPath; ?>images/ava-4.jpg" class="img-circle"/>
									</a>
									<div class="wrapper">
										<a href="<?php echo $tplPath; ?>#"><h5>Curabitur tincidunt porta lorem.</h5></a>
										<ul class="list-inline">
											<li><i class="fa fa-calendar"></i>25/3/2015</li>
											<li><i class="fa fa-thumbs-up"></i>1,200</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<!---- Start Widget ---->
						<div class="widget wid-banner">
							<div class="content">
								<img src="<?php echo $tplPath; ?>images/banner-2.jpg" class="img-responsive"/>
							</div>
						</div>
						<!---- Start Widget ---->
						<div class="widget wid-categoty">
							<div class="heading"><h4>Category</h4></div>
							<div class="content">
								<select class="col-md-12">
									<option>Mustard</option>
									<option>Ketchup</option>
									<option>Relish</option>
								</select>
							</div>
						</div>
						<!---- Start Widget ---->
						<div class="widget wid-calendar">
							<div class="heading"><h4>Calendar</h4></div>
							<div class="content">
								<form action="" role="form">
									<div class="">
										<div class="input-group date form_date" data-date="" data-date-format="dd MM yyyy" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">                </div>
										<input type="hidden" id="dtp_input2" value="">
                                        <br>
									</div>
								</form>
							</div>
						</div>
						<!---- Start Widget ---->
						<div class="widget wid-tweet">
							<div class="heading"><h4>Tweet</h4></div>
							<div class="content">
								<div class="tweet-item">
									<p><i class="fa fa-twitter"></i> TLAS - Coming Soon PSD Mockup</p>
									<a>https://t.co/dLsNZYGVbJ</a>
									<a>#psd</a>
									<a>#freebie</a>
									<a>#freebie</a>
									<a>#dribbble</a>
									<span>July 15th, 2015</span>
								</div>
								<div class="tweet-item">
									<p><i class="fa fa-twitter"></i> Little Dude Character With Multiple Hairs</p>
									<a>https://t.co/dLsNZYGVbJ</a>
									<a>#freebie</a>
									<a>#design</a>
									<a>#illustrator</a>
									<a>#dribbble</a>
									<span>June 23rd, 2015</span>
								</div>
								<div class="tweet-item">
									<p><i class="fa fa-twitter"></i> Newsletter Subscription Form Mockup</p>
									<a>https://t.co/dLsNZYGVbJ</a>
									<a>#psd</a>
									<a>#freebie</a>
									<a>#freebie</a>
									<a>#dribbble</a>
									<span>June 22nd, 2015</span>
								</div>
								<p>Marshall, Will, and Holly on a routine expedition, met the greatest earthquake ever known. High on the rapids, it struck their tiny raft...</p>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
		<footer>
			<div class="wrap-footer">
				<div class="container">
					<div class="row">
						<div class="col-md-4 col-footer footer-1">
							<div class="footer-heading"><h1><span style="color: #fff;">NEWSPAPER</span></h1></div>
							<div class="content">
								<p>Never missed any post published in our site. Subscribe to our daly newsletter now.</p>
								<strong>Email address:</strong>
								<form action="#" method="post">
									<input type="text" name="your-name" value="" size="40" placeholder="Your Email">
									<input type="submit" value="SUBSCRIBE" class="btn btn-3">
								</form>
							</div>
						</div>
						<div class="col-md-4 col-footer footer-2">
							<div class="footer-heading"><h4>Tags</h4></div>
							<div class="content">
								<a href="<?php echo $tplPath; ?>#">animals</a>
								<a href="<?php echo $tplPath; ?>#">cooking</a>
								<a href="<?php echo $tplPath; ?>#">countries</a>
								<a href="<?php echo $tplPath; ?>#">city</a>
								<a href="<?php echo $tplPath; ?>#">children</a>
								<a href="<?php echo $tplPath; ?>#">home</a>
								<a href="<?php echo $tplPath; ?>#">likes</a>
								<a href="<?php echo $tplPath; ?>#">photo</a>
								<a href="<?php echo $tplPath; ?>#">link</a>
								<a href="<?php echo $tplPath; ?>#">law</a>
								<a href="<?php echo $tplPath; ?>#">shopping</a>
								<a href="<?php echo $tplPath; ?>#">skate</a>
								<a href="<?php echo $tplPath; ?>#">scholl</a>
								<a href="<?php echo $tplPath; ?>#">video</a>
								<a href="<?php echo $tplPath; ?>#">travel</a>
								<a href="<?php echo $tplPath; ?>#">images</a>
								<a href="<?php echo $tplPath; ?>#">love</a>
								<a href="<?php echo $tplPath; ?>#">lists</a>
								<a href="<?php echo $tplPath; ?>#">makeup</a>
								<a href="<?php echo $tplPath; ?>#">media</a>
								<a href="<?php echo $tplPath; ?>#">password</a>
								<a href="<?php echo $tplPath; ?>#">pagination</a>
								<a href="<?php echo $tplPath; ?>#">wildlife</a>
							</div>
						</div>
						<div class="col-md-4 col-footer footer-3">
							<div class="footer-heading"><h4>Link List</h4></div>
							<div class="content">
								<ul>
									<li><a href="<?php echo $tplPath; ?>#">MOST VISITED COUNTRIES</a></li>
									<li><a href="<?php echo $tplPath; ?>#">5 PLACES THAT MAKE A GREAT HOLIDAY</a></li>
									<li><a href="<?php echo $tplPath; ?>#">PEBBLE TIME STEEL IS ON TRACK TO SHIP IN JULY</a></li>
									<li><a href="<?php echo $tplPath; ?>#">STARTUP COMPANY’S CO-FOUNDER TALKS ON HIS NEW PRODUCT</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="copy-right">
				<p>Copyright &copy; 2015.Company name All rights reserved.<a target="_blank" href="<?php echo $tplPath; ?>http://www.cssmoban.com/">&#x7F51;&#x9875;&#x6A21;&#x677F;</a></p>
			</div>
		</footer>
		<!-- Footer -->
		<!-- JS -->
		<!-- jQuery and Modernizr-->
		<script src="<?php echo $tplPath; ?>js/jquery-2.1.1.js"></script>
		<!-- Core JavaScript Files -->
		<script src="<?php echo $tplPath; ?>js/bootstrap.min.js"></script>
		<!--[if lt IE 9]>
		<script src="<?php echo $tplPath; ?>js/html5shiv.js"></script>
		<script src="<?php echo $tplPath; ?>js/respond.min.js"></script>
		<![endif]-->
		<script src="<?php echo $tplPath; ?>owl-carousel/owl.carousel.js"></script>
		<script src="<?php echo $tplPath; ?>js/bootstrap-datetimepicker.js"></script>
		<script src="<?php echo $tplPath; ?>js/bootstrap-datetimepicker.fr.js"></script>
		<script>
            $(document).ready(function() {
                $("#owl-demo-1").owlCarousel({
                    autoPlay: 3000,
                    items : 1,
                    itemsDesktop : [1199,1],
                    itemsDesktopSmall : [400,1]
                });
                $("#owl-demo-2").owlCarousel({
                    autoPlay: 3000,
                    items : 3
                });
            });
			$('.form_datetime').datetimepicker({
				//language:  'fr',
				weekStart: 1,
				todayBtn:  1,
				autoclose: 1,
				todayHighlight: 1,
				startView: 2,
				forceParse: 0,
				showMeridian: 1
			});
			$('.form_date').datetimepicker({
				language:  'fr',
				weekStart: 1,
				todayBtn:  1,
				autoclose: 1,
				todayHighlight: 1,
				startView: 2,
				minView: 2,
				forceParse: 0
			});
			$('.form_time').datetimepicker({
				language:  'fr',
				weekStart: 1,
				todayBtn:  1,
				autoclose: 1,
				todayHighlight: 1,
				startView: 1,
				minView: 0,
				maxView: 1,
				forceParse: 0
			});
		</script>
	</body>
</html>
