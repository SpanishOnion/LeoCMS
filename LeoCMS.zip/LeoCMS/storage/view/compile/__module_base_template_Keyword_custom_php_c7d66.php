<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>首页</title>
        <link rel="stylesheet" href="./resource/css/admin/bootstrap.min.css">
        <link rel="stylesheet" href="./resource/css/admin/common.css">
        <script src="./resource/font/admin/icon/iconfont.js"></script>
        <link rel="shortcut icon" href="./favicon.ico">
    </head>
    <body>
        <!--头部-->
        <header class="alert headInfo">
            <a class="headTitle" href="index.php?s=admin/Entry/index">
                    <span class="title-letter">
                        Leo<span class="colorful-0">C</span><span class="colorful-1">M</span><span class="colorful-2">S</span>
                    </span>
                <span>后台管理系统</span>
            </a>
            <div class="head-mid">
                <a class="headTitle title-manual title-config" href="index.php?s=admin/Entry/config">
                    <svg class="icon" aria-hidden="true"><use xlink:href="#icon-icon_xitongguanli"></use></svg>
                    网站配置
                </a>
                <a class="headTitle title-manual title-config" href="index.php?s=admin/Entry/dataList">
                    <svg class="icon" aria-hidden="true"><use xlink:href="#icon-hdm"></use></svg>
                    备份数据
                </a>
                <a class="headTitle title-manual title-config title-module" href="index.php?s=module/Module/index">
                    <svg class="icon" aria-hidden="true"><use xlink:href="#icon-iconsheji-"></use></svg>
                    模块管理
                </a>
                <a class="headTitle title-manual title-config title-wechat" href="index.php?s=wechat/Config/index">
                    <svg class="icon" aria-hidden="true"><use xlink:href="#icon-weixin"></use></svg>
                    <span>微信系统管理</span>
                </a>
                <a class="headTitle title-manual title-muan" href="http://doc.hdphp.com/215149" target="_blank">
                    <svg class="icon" aria-hidden="true"><use xlink:href="#icon-bangzhushouce"></use></svg>
                    <span>开发手册</span>
                </a>
                <a class="headTitle title-manual title-config title-icon" href="http://iconfont.cn/home/index?spm=a313x.7781069.1998910419.2" target="_blank">
                    <svg class="icon icon-house" aria-hidden="true"><use xlink:href="#icon-xingxing"></use></svg>
                    图标库
                </a>
            </div>
            <?php if(Session::has('cmsAdmin')) { ?>
                <div class="headUser">
                    <span>Hi，</span>
                    <span class="username"><?php echo Session::get('cmsAdmin'); ?></span>
                    <span>！欢迎回来 ~</span>
                    <button class="btn btn-danger btn-signOut">退出</button>
                    <button class="btn btn-primary btn-switch">切换账号</button>
                </div>
            <?php } ?>
        </header>
        <!--头部end-->
        <!-- 菜单栏 -->
        <div class="col-xs-12 col-sm-3 col-lg-2 left-menu">
            <div class="panel panel-default" id="menus">
                <!--学院管理-->
                <details><summary><span>基本设置</span></summary></details>
                <ul class="menus">
                    <li>
                        <a href="index.php?s=wechat/Config/index">
                            <svg class="icon" aria-hidden="true"><use xlink:href="#icon-drxx08"></use></svg>
                            公众号配置
                        </a>
                    </li>
                </ul>
                <!--分类管理-->
                <details><summary><span>回复管理</span></summary></details>
                <ul class="menus menus-m">
                    <!--<li>
                        <a href="index.php?a=base/Keyword/system">
                            <svg class="icon" aria-hidden="true"><use xlink:href="#icon-icon_hangyefenlei"></use></svg>
                            系统回复
                        </a>
                    </li>-->
                    <li>
                        <a href="index.php?a=base/Keyword/custom">
                            <svg class="icon" aria-hidden="true"><use xlink:href="#icon-icon_hangyefenlei"></use></svg>
                            关键词回复
                        </a>
                    </li>
                </ul>
                <!--文章管理-->
                <details><summary><span>菜单管理</span></summary></details>
                <ul class="menus">
                    <li>
                        <a href="index.php?s=admin/Article/index">
                            <svg class="icon" aria-hidden="true"><use xlink:href="#icon-liebiaocaidan"></use></svg>
                            菜单列表
                        </a>
                    </li>
                </ul>
                <!--班级管理-->
                <details>
                    <summary><span>微商城</span></summary>
                </details>
                <ul class="menus">
                    <li>
                        <a href="index.php?s=admin/Photo/index">
                            <svg class="icon" aria-hidden="true"><use xlink:href="#icon-tupian"></use></svg>
                            商品列表
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- 菜单栏end -->
        
    <div class="form-list container form-list-main">
        <div class="alert headInfo atcHead">
            <button class="btn btn-info" id="kw-add">添加关键词</button>
        </div>
        <div class="list-article">
            <table class="table table-hover">
                <tbody id="tb">
                    <tr>
                        <th>序号</th>
                        <th>关键词</th>
                        <th>回复内容</th>
                        <th>操作</th>
                    </tr>
                    <?php foreach($data as $k=>$v){ ?>
                    <tr data-id="<?php echo $v['id']; ?>">
                        <td><?php echo $k + 1; ?></td>
                        <td><?php echo $v['name']; ?></td>
                        <td><?php echo $v['content']; ?></td>
                        <td>
                            <button class="btn btn-success btn-xs edt-btn">编辑该关键词</button>
                            <button class="btn btn-off btn-xs del-btn">删除该关键词</button>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
            <hr>
        </div>
        <form id="form">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">关键词</label>
                        <div class="col-sm-9">
                            <input class="form-control" id="name" name="name" type="text" placeholder="请输入关键词">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">回复内容</label>
                        <div class="col-sm-9">
                            <textarea class="form-control" id="content" name="content" type="text"  placeholder="请输入回复内容"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label"></label>
                        <button class="btn btn-info btn-sub" id="btn-sub" type="button">立刻保存</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

        <div class="body-bg"></div>
        <footer>Copyright© 2017-2018 李聪 Leo 个人博客 版权所有</footer>
        <script src="./resource/js/common/helper.js"></script>
        <script src="./resource/js/wechat/master.js"></script>
        <?php if(v('co') == 'Config'){ ?>
            <script src="./resource/js/wechat/config/index.js"></script>
        <?php } else if(v('co') == 'Category') { ?>
            <script src="./resource/js/admin/category/index.js"></script>
        <?php } else if(v('co') == 'Keyword') { ?>
            <script src="./resource/js/module/base/keyword.js"></script>
        <?php } ?>
    </body>
</html>
