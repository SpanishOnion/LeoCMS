<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Newspaper</title>
    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="<?php echo $tplPath; ?>css/bootstrap.min.css">
    <!-- Owl Carousel Assets -->
    <link rel="stylesheet" href="<?php echo $tplPath; ?>owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="<?php echo $tplPath; ?>owl-carousel/owl.theme.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo $tplPath; ?>css/style.css">
    <link rel="stylesheet" href="<?php echo $tplPath; ?>css/bootstrap-datetimepicker.min.css" media="screen">
    <!-- Custom Fonts -->
    <link rel="stylesheet" href="<?php echo $tplPath; ?>font-awesome-4.4.0/css/font-awesome.min.css">
</head>
<body>
    <header>
        <!--Top-->
        <nav id="top">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <strong>Welcome to Us!</strong>
                    </div>
                    <div class="col-md-6">
                        <ul class="list-inline top-link link">
                            <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
                            <li><a href="<?php echo $tplPath; ?>contact.html"><i class="fa fa-comments"></i> Contact</a></li>
                            <li><a href="/"><i class="fa fa-question-circle"></i> FAQ</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
        <!--Navigation-->
        <nav id="menu" class="navbar container">
            <div class="navbar-header">
                <button type="button" class="btn btn-navbar navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="/">
                    <div class="logo"><span>Newspaper</span></div>
                </a>
            </div>
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav">
                    <li><a href="/">首页</a></li>
                    <?php foreach($cate as $k=>$v){ ?>
                    <li class="dropdown">
                        <a href="/l/<?php echo $v['id']; ?>"><?php echo $v['name']; ?>电影
                            <i class="fa fa-arrow-circle-o-down"></i>
                        </a>
                        <!--<div class="dropdown-menu">-->
                        <!--<div class="dropdown-inner">-->
                        <!--<ul class="list-unstyled">-->
                        <!--<li><a href="<?php echo $tplPath; ?>archive.html">Login</a></li>-->
                        <!--<li><a href="<?php echo $tplPath; ?>archive.html">Register</a></li>-->
                        <!--</ul>-->
                        <!--</div>-->
                        <!--</div>-->
                    </li>
                    <?php } ?>
                </ul>
                <ul class="list-inline navbar-right top-social">
                    <li><a href="/"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="/"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="/"><i class="fa fa-pinterest"></i></a></li>
                    <li><a href="/"><i class="fa fa-google-plus-square"></i></a></li>
                    <li><a href="/"><i class="fa fa-youtube"></i></a></li>
                </ul>
            </div>
        </nav>
    </header>
    <!--blade_content-->
    <footer>
        <div class="wrap-footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-footer footer-1">
                        <div class="footer-heading"><h1><span style="color: #fff;">NEWSPAPER</span></h1></div>
                        <div class="content">
                            <p>Never missed any post published in our site. Subscribe to our daly newsletter now.</p>
                            <strong>Email address:</strong>
                            <form action="#" method="post">
                                <input type="text" name="your-name" value="" size="40" placeholder="Your Email">
                                <input type="submit" value="SUBSCRIBE" class="btn btn-3">
                            </form>
                        </div>
                    </div>
                    <div class="col-md-4 col-footer footer-2">
                        <div class="footer-heading"><h4>Tags</h4></div>
                        <div class="content">
                            <a href="/">animals</a>
                            <a href="/">cooking</a>
                            <a href="/">countries</a>
                            <a href="/">city</a>
                            <a href="/">children</a>
                            <a href="/">home</a>
                            <a href="/">likes</a>
                            <a href="/">photo</a>
                            <a href="/">link</a>
                            <a href="/">law</a>
                            <a href="/">shopping</a>
                            <a href="/">skate</a>
                            <a href="/">scholl</a>
                            <a href="/">video</a>
                            <a href="/">travel</a>
                            <a href="/">images</a>
                            <a href="/">love</a>
                            <a href="/">lists</a>
                            <a href="/">makeup</a>
                            <a href="/">media</a>
                            <a href="/">password</a>
                            <a href="/">pagination</a>
                            <a href="/">wildlife</a>
                        </div>
                    </div>
                    <div class="col-md-4 col-footer footer-3">
                        <div class="footer-heading"><h4>Link List</h4></div>
                        <div class="content">
                            <ul>
                                <li><a href="/">MOST VISITED COUNTRIES</a></li>
                                <li><a href="/">5 PLACES THAT MAKE A GREAT HOLIDAY</a></li>
                                <li><a href="/">PEBBLE TIME STEEL IS ON TRACK TO SHIP IN JULY</a></li>
                                <li><a href="/">STARTUP COMPANY’S CO-FOUNDER TALKS ON HIS NEW PRODUCT</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copy-right">
            <p>Copyright &copy; 2015.Company name All rights reserved.<a target="_blank" href="<?php echo $tplPath; ?>http://www.cssmoban.com/">&#x7F51;&#x9875;&#x6A21;&#x677F;</a></p>
        </div>
    </footer>
    <script src="<?php echo $tplPath; ?>js/jquery-2.1.1.js"></script>
    <script src="<?php echo $tplPath; ?>js/bootstrap.min.js"></script>
    <script src="<?php echo $tplPath; ?>owl-carousel/owl.carousel.js"></script>
    <!--[if lt IE 9]>
    <script src="<?php echo $tplPath; ?>js/html5shiv.js"></script>
    <script src="<?php echo $tplPath; ?>js/respond.min.js"></script>
    <![endif]-->
    <?php if ($ac == 0) { ?>
    <script src="<?php echo $tplPath; ?>js/bootstrap-datetimepicker.js"></script>
    <script src="<?php echo $tplPath; ?>js/bootstrap-datetimepicker.fr.js"></script>
    <script>
        $(document).ready(function() {
            $("#owl-demo-1").owlCarousel({
                autoPlay: 3000,
                items : 1,
                itemsDesktop : [1199,1],
                itemsDesktopSmall : [400,1]
            });
            $("#owl-demo-2").owlCarousel({
                autoPlay: 3000,
                items : 3
            });
        });
        $('.form_datetime').datetimepicker({
            weekStart: 1,
            todayBtn:  1,
            autoclose: 1,
            todayHighlight: 1,
            startView: 2,
            forceParse: 0,
            showMeridian: 1
        });
        $('.form_date').datetimepicker({
            language:  'fr',
            weekStart: 1,
            todayBtn:  1,
            autoclose: 1,
            todayHighlight: 1,
            startView: 2,
            minView: 2,
            forceParse: 0
        });
        $('.form_time').datetimepicker({
            language:  'fr',
            weekStart: 1,
            todayBtn:  1,
            autoclose: 1,
            todayHighlight: 1,
            startView: 1,
            minView: 0,
            maxView: 1,
            forceParse: 0
        });
    </script>
    <?php } else { ?>
        <script>
            $(document).ready(function() {
                $("#owl-demo").owlCarousel({
                    autoPlay: 3000,
                    items : 5,
                    itemsDesktop : [1199,4],
                    itemsDesktopSmall : [979,4]
                });

            });
        </script>
    <?php } ?>
</body>
</html>